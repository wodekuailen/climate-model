package com.digitalhuman.app.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.digitalhuman.app.R
import com.digitalhuman.app.models.KnowledgeEntry

/**
 * 知识库条目适配器
 */
class KnowledgeAdapter(
    private val onEditClick: (KnowledgeEntry) -> Unit,
    private val onDeleteClick: (KnowledgeEntry) -> Unit
) : ListAdapter<KnowledgeEntry, KnowledgeAdapter.KnowledgeViewHolder>(KnowledgeDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): KnowledgeViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_knowledge_entry, parent, false)
        return KnowledgeViewHolder(view)
    }

    override fun onBindViewHolder(holder: KnowledgeViewHolder, position: Int) {
        val entry = getItem(position)
        holder.bind(entry, onEditClick, onDeleteClick)
    }

    class KnowledgeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val questionTextView: TextView = itemView.findViewById(R.id.questionTextView)
        private val answerTextView: TextView = itemView.findViewById(R.id.answerTextView)
        private val editButton: ImageButton = itemView.findViewById(R.id.editButton)
        private val deleteButton: ImageButton = itemView.findViewById(R.id.deleteButton)

        fun bind(
            entry: KnowledgeEntry,
            onEditClick: (KnowledgeEntry) -> Unit,
            onDeleteClick: (KnowledgeEntry) -> Unit
        ) {
            questionTextView.text = entry.question
            answerTextView.text = entry.answer
            
            editButton.setOnClickListener {
                onEditClick(entry)
            }
            
            deleteButton.setOnClickListener {
                onDeleteClick(entry)
            }
        }
    }

    /**
     * 用于比较知识库条目差异的回调
     */
    class KnowledgeDiffCallback : DiffUtil.ItemCallback<KnowledgeEntry>() {
        override fun areItemsTheSame(oldItem: KnowledgeEntry, newItem: KnowledgeEntry): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: KnowledgeEntry, newItem: KnowledgeEntry): Boolean {
            return oldItem == newItem
        }
    }
} 