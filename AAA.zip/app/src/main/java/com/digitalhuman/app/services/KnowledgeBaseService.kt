package com.digitalhuman.app.services

import android.content.Context
import com.digitalhuman.app.data.AppDatabase
import com.digitalhuman.app.models.KnowledgeEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.FileReader

/**
 * 知识库服务，负责管理和查询知识库
 */
class KnowledgeBaseService(context: Context) {

    private val knowledgeDao = AppDatabase.getDatabase(context).knowledgeDao()
    
    /**
     * 查询知识库
     */
    suspend fun queryKnowledgeBase(query: String): String {
        val entries = knowledgeDao.searchEntries(query)
        if (entries.isNotEmpty()) {
            // 简单匹配，返回第一个匹配项的答案
            return entries[0].answer
        }
        return ""
    }
    
    /**
     * 添加知识条目
     */
    suspend fun addKnowledgeEntry(question: String, answer: String) {
        // 提取关键词，简单实现为分词并去重
        val keywords = extractKeywords(question)
        
        val entry = KnowledgeEntry(
            question = question,
            answer = answer,
            keywords = keywords.joinToString(",")
        )
        
        knowledgeDao.insert(entry)
    }
    
    /**
     * 更新知识条目
     */
    suspend fun updateKnowledgeEntry(entry: KnowledgeEntry) {
        knowledgeDao.update(entry)
    }
    
    /**
     * 删除知识条目
     */
    suspend fun deleteKnowledgeEntry(entry: KnowledgeEntry) {
        knowledgeDao.delete(entry)
    }
    
    /**
     * 获取所有知识条目
     */
    suspend fun getAllEntries(): List<KnowledgeEntry> {
        return knowledgeDao.getAllEntries()
    }
    
    /**
     * 导入知识库
     */
    suspend fun importKnowledgeBase(filePath: String) {
        withContext(Dispatchers.IO) {
            try {
                val file = File(filePath)
                if (!file.exists()) return@withContext
                
                val reader = BufferedReader(FileReader(file))
                val jsonString = reader.readText()
                reader.close()
                
                // 解析JSON格式的知识库
                val jsonArray = JSONArray(jsonString)
                for (i in 0 until jsonArray.length()) {
                    val jsonObject = jsonArray.getJSONObject(i)
                    val question = jsonObject.getString("question")
                    val answer = jsonObject.getString("answer")
                    
                    addKnowledgeEntry(question, answer)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    /**
     * 导出知识库
     */
    suspend fun exportKnowledgeBase(filePath: String) {
        withContext(Dispatchers.IO) {
            try {
                val entries = knowledgeDao.getAllEntries()
                val jsonArray = JSONArray()
                
                for (entry in entries) {
                    val jsonObject = JSONObject()
                    jsonObject.put("question", entry.question)
                    jsonObject.put("answer", entry.answer)
                    jsonArray.put(jsonObject)
                }
                
                val file = File(filePath)
                file.writeText(jsonArray.toString(2))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    /**
     * 从问题中提取关键词
     */
    private fun extractKeywords(question: String): List<String> {
        // 简单实现，实际应用中应使用更复杂的分词和关键词提取算法
        return question.split(" ", "，", "。", "？", "！")
            .filter { it.isNotEmpty() && it.length > 1 }
            .distinct()
    }
} 