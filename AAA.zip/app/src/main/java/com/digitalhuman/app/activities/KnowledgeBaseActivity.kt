package com.digitalhuman.app.activities

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.digitalhuman.app.adapters.KnowledgeAdapter
import com.digitalhuman.app.databinding.ActivityKnowledgeBaseBinding
import com.digitalhuman.app.models.KnowledgeEntry
import com.digitalhuman.app.services.KnowledgeBaseService
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

class KnowledgeBaseActivity : AppCompatActivity() {

    private lateinit var binding: ActivityKnowledgeBaseBinding
    private lateinit var knowledgeAdapter: KnowledgeAdapter
    private lateinit var knowledgeBaseService: KnowledgeBaseService
    
    private val openDocument = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { importKnowledgeBase(it) }
    }
    
    private val createDocument = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri?.let { exportKnowledgeBase(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityKnowledgeBaseBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // 设置标题栏
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "知识库管理"
        
        knowledgeBaseService = KnowledgeBaseService(applicationContext)
        
        setupRecyclerView()
        setupUI()
        loadKnowledgeEntries()
    }
    
    private fun setupRecyclerView() {
        knowledgeAdapter = KnowledgeAdapter(
            onEditClick = { entry -> showEditDialog(entry) },
            onDeleteClick = { entry -> deleteEntry(entry) }
        )
        
        binding.knowledgeRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@KnowledgeBaseActivity)
            adapter = knowledgeAdapter
        }
    }
    
    private fun setupUI() {
        // 添加新条目按钮
        binding.addButton.setOnClickListener {
            showAddDialog()
        }
        
        // 导入知识库按钮
        binding.importButton.setOnClickListener {
            openDocument.launch(arrayOf("application/json"))
        }
        
        // 导出知识库按钮
        binding.exportButton.setOnClickListener {
            createDocument.launch("knowledge_base.json")
        }
    }
    
    private fun loadKnowledgeEntries() {
        lifecycleScope.launch {
            val entries = knowledgeBaseService.getAllEntries()
            knowledgeAdapter.submitList(entries)
        }
    }
    
    private fun showAddDialog() {
        val dialog = KnowledgeEntryDialog(
            context = this,
            onSave = { question, answer ->
                addEntry(question, answer)
            }
        )
        dialog.show()
    }
    
    private fun showEditDialog(entry: KnowledgeEntry) {
        val dialog = KnowledgeEntryDialog(
            context = this,
            initialQuestion = entry.question,
            initialAnswer = entry.answer,
            onSave = { question, answer ->
                updateEntry(entry.copy(question = question, answer = answer))
            }
        )
        dialog.show()
    }
    
    private fun addEntry(question: String, answer: String) {
        lifecycleScope.launch {
            knowledgeBaseService.addKnowledgeEntry(question, answer)
            loadKnowledgeEntries()
            Toast.makeText(this@KnowledgeBaseActivity, "已添加知识条目", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun updateEntry(entry: KnowledgeEntry) {
        lifecycleScope.launch {
            knowledgeBaseService.updateKnowledgeEntry(entry)
            loadKnowledgeEntries()
            Toast.makeText(this@KnowledgeBaseActivity, "已更新知识条目", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun deleteEntry(entry: KnowledgeEntry) {
        lifecycleScope.launch {
            knowledgeBaseService.deleteKnowledgeEntry(entry)
            loadKnowledgeEntries()
            Toast.makeText(this@KnowledgeBaseActivity, "已删除知识条目", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun importKnowledgeBase(uri: Uri) {
        lifecycleScope.launch {
            try {
                // 将URI内容复制到临时文件
                val inputStream = contentResolver.openInputStream(uri)
                val tempFile = File(cacheDir, "temp_knowledge_base.json")
                val outputStream = FileOutputStream(tempFile)
                
                inputStream?.use { input ->
                    outputStream.use { output ->
                        input.copyTo(output)
                    }
                }
                
                // 导入知识库
                knowledgeBaseService.importKnowledgeBase(tempFile.absolutePath)
                loadKnowledgeEntries()
                Toast.makeText(this@KnowledgeBaseActivity, "知识库导入成功", Toast.LENGTH_SHORT).show()
                
                // 删除临时文件
                tempFile.delete()
            } catch (e: Exception) {
                Toast.makeText(this@KnowledgeBaseActivity, "导入失败: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun exportKnowledgeBase(uri: Uri) {
        lifecycleScope.launch {
            try {
                // 先导出到临时文件
                val tempFile = File(cacheDir, "temp_export.json")
                knowledgeBaseService.exportKnowledgeBase(tempFile.absolutePath)
                
                // 将临时文件写入到选择的URI
                val outputStream = contentResolver.openOutputStream(uri)
                outputStream?.use { output ->
                    tempFile.inputStream().use { input ->
                        input.copyTo(output)
                    }
                }
                
                Toast.makeText(this@KnowledgeBaseActivity, "知识库导出成功", Toast.LENGTH_SHORT).show()
                
                // 删除临时文件
                tempFile.delete()
            } catch (e: Exception) {
                Toast.makeText(this@KnowledgeBaseActivity, "导出失败: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
} 