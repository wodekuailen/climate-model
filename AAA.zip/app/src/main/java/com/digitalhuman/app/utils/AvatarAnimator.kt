package com.digitalhuman.app.utils

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ImageView

/**
 * 数字人头像动画工具类
 */
class AvatarAnimator(private val avatarView: ImageView) {

    private var isAnimating = false
    private var animatorSet: AnimatorSet? = null

    /**
     * 开始说话动画
     */
    fun startSpeakingAnimation() {
        if (isAnimating) return
        
        // 创建一个简单的缩放动画
        val scaleX = ObjectAnimator.ofFloat(avatarView, View.SCALE_X, 1.0f, 1.05f, 1.0f)
        val scaleY = ObjectAnimator.ofFloat(avatarView, View.SCALE_Y, 1.0f, 1.05f, 1.0f)
        
        scaleX.repeatCount = ObjectAnimator.INFINITE
        scaleY.repeatCount = ObjectAnimator.INFINITE
        
        scaleX.duration = 1000
        scaleY.duration = 1000
        
        // 创建动画集
        animatorSet = AnimatorSet().apply {
            playTogether(scaleX, scaleY)
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        
        isAnimating = true
    }

    /**
     * 停止说话动画
     */
    fun stopSpeakingAnimation() {
        if (!isAnimating) return
        
        animatorSet?.cancel()
        
        // 重置缩放
        avatarView.scaleX = 1.0f
        avatarView.scaleY = 1.0f
        
        isAnimating = false
    }

    /**
     * 播放一次点头动画
     */
    fun playNodAnimation() {
        val rotation = ObjectAnimator.ofFloat(avatarView, View.ROTATION_X, 0f, 10f, 0f)
        rotation.duration = 500
        rotation.interpolator = AccelerateDecelerateInterpolator()
        rotation.start()
    }

    /**
     * 播放一次摇头动画
     */
    fun playShakeAnimation() {
        val rotation = ObjectAnimator.ofFloat(avatarView, View.ROTATION, 0f, -5f, 5f, 0f)
        rotation.duration = 500
        rotation.interpolator = AccelerateDecelerateInterpolator()
        rotation.start()
    }
} 