package com.digitalhuman.app.models

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * 知识库条目实体类
 */
@Entity(tableName = "knowledge_entries")
data class KnowledgeEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val question: String,
    val answer: String,
    val keywords: String, // 用于快速匹配的关键词，以逗号分隔
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) 