package com.digitalhuman.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeech.OnUtteranceProgressListener
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.digitalhuman.app.activities.KnowledgeBaseActivity
import com.digitalhuman.app.adapters.MessageAdapter
import com.digitalhuman.app.databinding.ActivityMainBinding
import com.digitalhuman.app.models.Message
import com.digitalhuman.app.utils.AvatarAnimator
import com.digitalhuman.app.viewmodels.MainViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var messageAdapter: MessageAdapter
    private lateinit var avatarAnimator: AvatarAnimator
    
    private val RECORD_AUDIO_PERMISSION_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        viewModel = ViewModelProvider(this)[MainViewModel::class.java]
        avatarAnimator = AvatarAnimator(binding.avatarImageView)
        
        setupRecyclerView()
        setupUI()
        observeViewModel()
        setupSpeechSynthesisListener()
        checkPermissions()
    }
    
    private fun setupRecyclerView() {
        messageAdapter = MessageAdapter()
        binding.chatRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity).apply {
                stackFromEnd = true // 从底部开始显示
            }
            adapter = messageAdapter
        }
    }
    
    private fun setupUI() {
        // 设置发送按钮点击事件
        binding.sendButton.setOnClickListener {
            val userInput = binding.messageInput.text.toString().trim()
            if (userInput.isNotEmpty()) {
                sendMessage(userInput)
                binding.messageInput.text.clear()
            }
        }
        
        // 设置语音按钮点击事件
        binding.voiceButton.setOnClickListener {
            if (checkAudioPermission()) {
                toggleVoiceRecording()
            } else {
                requestAudioPermission()
            }
        }
        
        // 设置知识库按钮点击事件
        binding.knowledgeBaseButton.setOnClickListener {
            // 打开知识库管理界面
            val intent = Intent(this, KnowledgeBaseActivity::class.java)
            startActivity(intent)
        }
        
        // 设置头像点击事件
        binding.avatarImageView.setOnClickListener {
            avatarAnimator.playNodAnimation()
        }
    }
    
    private fun observeViewModel() {
        // 观察聊天历史
        viewModel.chatHistory.observe(this) { messages ->
            messageAdapter.submitList(messages)
            // 滚动到最新消息
            if (messages.isNotEmpty()) {
                binding.chatRecyclerView.scrollToPosition(messages.size - 1)
            }
        }
        
        // 观察语音识别状态
        viewModel.isRecording.observe(this) { isRecording ->
            binding.voiceButton.isSelected = isRecording
            if (isRecording) {
                binding.voiceButton.setImageResource(android.R.drawable.ic_media_pause)
                Toast.makeText(this, "正在录音...", Toast.LENGTH_SHORT).show()
            } else {
                binding.voiceButton.setImageResource(android.R.drawable.ic_btn_speak_now)
            }
        }
        
        // 观察语音识别结果
        viewModel.recognizedText.observe(this) { text ->
            if (text.isNotEmpty()) {
                binding.messageInput.setText(text)
            }
        }
        
        // 观察数字人响应
        viewModel.digitalHumanResponse.observe(this) { response ->
            // 当有新响应时，播放点头动画
            avatarAnimator.playNodAnimation()
        }
    }
    
    private fun setupSpeechSynthesisListener() {
        viewModel.setSpeechSynthesisListener(object : OnUtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                runOnUiThread {
                    avatarAnimator.startSpeakingAnimation()
                }
            }
            
            override fun onDone(utteranceId: String?) {
                runOnUiThread {
                    avatarAnimator.stopSpeakingAnimation()
                }
            }
            
            override fun onError(utteranceId: String?) {
                runOnUiThread {
                    avatarAnimator.stopSpeakingAnimation()
                }
            }
        })
    }
    
    private fun sendMessage(message: String) {
        // 发送消息到ViewModel处理
        viewModel.processUserInput(message)
    }
    
    private fun toggleVoiceRecording() {
        val isCurrentlyRecording = viewModel.isRecording.value ?: false
        if (isCurrentlyRecording) {
            viewModel.stopVoiceRecording()
        } else {
            viewModel.startVoiceRecording()
        }
    }
    
    private fun checkAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }
    
    private fun requestAudioPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.RECORD_AUDIO),
            RECORD_AUDIO_PERMISSION_CODE
        )
    }
    
    private fun checkPermissions() {
        if (!checkAudioPermission()) {
            requestAudioPermission()
        }
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == RECORD_AUDIO_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "语音权限已授予", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "需要语音权限才能使用语音功能", Toast.LENGTH_SHORT).show()
            }
        }
    }
} 