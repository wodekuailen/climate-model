package com.digitalhuman.app.data

import androidx.room.*
import com.digitalhuman.app.models.KnowledgeEntry

/**
 * 知识库数据访问对象
 */
@Dao
interface KnowledgeDao {
    
    @Insert
    suspend fun insert(entry: KnowledgeEntry): Long
    
    @Update
    suspend fun update(entry: KnowledgeEntry)
    
    @Delete
    suspend fun delete(entry: KnowledgeEntry)
    
    @Query("SELECT * FROM knowledge_entries")
    suspend fun getAllEntries(): List<KnowledgeEntry>
    
    @Query("SELECT * FROM knowledge_entries WHERE id = :id")
    suspend fun getEntryById(id: Long): KnowledgeEntry?
    
    @Query("SELECT * FROM knowledge_entries WHERE question LIKE '%' || :query || '%' OR keywords LIKE '%' || :query || '%' LIMIT 5")
    suspend fun searchEntries(query: String): List<KnowledgeEntry>
    
    @Query("DELETE FROM knowledge_entries")
    suspend fun deleteAll()
} 