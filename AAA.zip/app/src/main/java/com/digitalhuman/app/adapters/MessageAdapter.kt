package com.digitalhuman.app.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.digitalhuman.app.R
import com.digitalhuman.app.models.Message

/**
 * 消息适配器，用于显示聊天消息列表
 */
class MessageAdapter : ListAdapter<Message, MessageAdapter.MessageViewHolder>(MessageDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_message, parent, false)
        return MessageViewHolder(view)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val message = getItem(position)
        holder.bind(message)
    }

    class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val userMessageCard: CardView = itemView.findViewById(R.id.userMessageCard)
        private val userMessageText: TextView = itemView.findViewById(R.id.userMessageText)
        private val digitalHumanMessageCard: CardView = itemView.findViewById(R.id.digitalHumanMessageCard)
        private val digitalHumanMessageText: TextView = itemView.findViewById(R.id.digitalHumanMessageText)

        fun bind(message: Message) {
            if (message.isUser) {
                // 显示用户消息
                userMessageCard.visibility = View.VISIBLE
                digitalHumanMessageCard.visibility = View.GONE
                userMessageText.text = message.content
            } else {
                // 显示数字人消息
                userMessageCard.visibility = View.GONE
                digitalHumanMessageCard.visibility = View.VISIBLE
                digitalHumanMessageText.text = message.content
            }
        }
    }

    /**
     * 用于比较消息项差异的回调
     */
    class MessageDiffCallback : DiffUtil.ItemCallback<Message>() {
        override fun areItemsTheSame(oldItem: Message, newItem: Message): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Message, newItem: Message): Boolean {
            return oldItem == newItem
        }
    }
} 