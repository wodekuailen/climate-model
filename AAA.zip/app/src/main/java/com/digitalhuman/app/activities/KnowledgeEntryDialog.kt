package com.digitalhuman.app.activities

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.Window
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.digitalhuman.app.R

/**
 * 知识库条目编辑对话框
 */
class KnowledgeEntryDialog(
    context: Context,
    private val initialQuestion: String = "",
    private val initialAnswer: String = "",
    private val onSave: (question: String, answer: String) -> Unit
) : Dialog(context) {

    private lateinit var questionEditText: EditText
    private lateinit var answerEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var cancelButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.dialog_knowledge_entry)
        
        // 初始化视图
        questionEditText = findViewById(R.id.questionEditText)
        answerEditText = findViewById(R.id.answerEditText)
        saveButton = findViewById(R.id.saveButton)
        cancelButton = findViewById(R.id.cancelButton)
        
        // 设置初始值
        questionEditText.setText(initialQuestion)
        answerEditText.setText(initialAnswer)
        
        // 设置点击事件
        saveButton.setOnClickListener {
            val question = questionEditText.text.toString().trim()
            val answer = answerEditText.text.toString().trim()
            
            if (question.isEmpty()) {
                Toast.makeText(context, "问题不能为空", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            if (answer.isEmpty()) {
                Toast.makeText(context, "回答不能为空", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            onSave(question, answer)
            dismiss()
        }
        
        cancelButton.setOnClickListener {
            dismiss()
        }
    }
} 