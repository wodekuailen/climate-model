package com.digitalhuman.app.viewmodels

import android.app.Application
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeech.OnUtteranceProgressListener
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.digitalhuman.app.models.Message
import com.digitalhuman.app.services.KnowledgeBaseService
import com.digitalhuman.app.services.SpeechRecognitionService
import com.digitalhuman.app.services.SpeechSynthesisService
import com.digitalhuman.app.services.TextProcessingService
import com.digitalhuman.app.utils.ModelLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val speechRecognitionService = SpeechRecognitionService(application)
    private val speechSynthesisService = SpeechSynthesisService(application)
    private val textProcessingService = TextProcessingService()
    private val knowledgeBaseService = KnowledgeBaseService(application)
    private val modelLoader = ModelLoader(application)

    // 数字人响应
    private val _digitalHumanResponse = MutableLiveData<String>()
    val digitalHumanResponse: LiveData<String> = _digitalHumanResponse

    // 语音识别状态
    private val _isRecording = MutableLiveData<Boolean>()
    val isRecording: LiveData<Boolean> = _isRecording

    // 语音识别结果
    private val _recognizedText = MutableLiveData<String>()
    val recognizedText: LiveData<String> = _recognizedText

    // 聊天历史
    private val _chatHistory = MutableLiveData<List<Message>>()
    val chatHistory: LiveData<List<Message>> = _chatHistory

    // 初始化聊天历史
    private val messageList = mutableListOf<Message>()

    init {
        _isRecording.value = false
        
        // 设置语音识别回调
        speechRecognitionService.setRecognitionCallback { text ->
            _recognizedText.postValue(text)
        }
        
        // 初始化模型
        initializeModel()
    }
    
    /**
     * 设置语音合成监听器
     */
    fun setSpeechSynthesisListener(listener: OnUtteranceProgressListener) {
        speechSynthesisService.setProgressListener(listener)
    }
    
    /**
     * 初始化模型
     */
    private fun initializeModel() {
        viewModelScope.launch(Dispatchers.IO) {
            // 加载模型配置
            val config = modelLoader.loadModelConfig()
            if (config != null) {
                textProcessingService.setModelConfig(config)
            }
            
            // 加载模型
            modelLoader.loadModel(textProcessingService)
        }
    }

    /**
     * 处理用户输入（文本或语音）
     */
    fun processUserInput(input: String) {
        viewModelScope.launch {
            // 添加用户消息到历史
            val userMessage = Message(content = input, isUser = true)
            messageList.add(userMessage)
            _chatHistory.postValue(messageList.toList())

            // 处理用户输入并获取响应
            val response = withContext(Dispatchers.IO) {
                // 首先检查知识库中是否有匹配的回答
                val knowledgeBaseResponse = knowledgeBaseService.queryKnowledgeBase(input)
                
                // 如果知识库中有匹配的回答，直接返回
                if (knowledgeBaseResponse.isNotEmpty()) {
                    return@withContext knowledgeBaseResponse
                }
                
                // 否则使用文本处理服务生成回答
                textProcessingService.processText(input)
            }

            // 添加数字人响应到历史
            val digitalHumanMessage = Message(content = response, isUser = false)
            messageList.add(digitalHumanMessage)
            _chatHistory.postValue(messageList.toList())

            // 更新数字人响应
            _digitalHumanResponse.postValue(response)

            // 语音合成响应
            speechSynthesisService.speak(response)
        }
    }

    /**
     * 开始语音录制
     */
    fun startVoiceRecording() {
        speechRecognitionService.startListening()
        _isRecording.value = true
    }

    /**
     * 停止语音录制
     */
    fun stopVoiceRecording() {
        speechRecognitionService.stopListening()
        _isRecording.value = false
    }

    /**
     * 添加知识到知识库
     */
    fun addToKnowledgeBase(question: String, answer: String) {
        viewModelScope.launch(Dispatchers.IO) {
            knowledgeBaseService.addKnowledgeEntry(question, answer)
        }
    }

    /**
     * 导入知识库
     */
    fun importKnowledgeBase(filePath: String) {
        viewModelScope.launch(Dispatchers.IO) {
            knowledgeBaseService.importKnowledgeBase(filePath)
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechRecognitionService.release()
        speechSynthesisService.release()
        textProcessingService.release()
    }
} 