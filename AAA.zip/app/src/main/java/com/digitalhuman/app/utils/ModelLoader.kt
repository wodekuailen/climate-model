package com.digitalhuman.app.utils

import android.content.Context
import com.digitalhuman.app.services.TextProcessingService
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * TensorFlow Lite模型加载器
 */
class ModelLoader(private val context: Context) {

    companion object {
        private const val MODEL_FILE_NAME = "digital_human_lite.tflite"
        private const val CONFIG_FILE_NAME = "model_config.json"
    }

    /**
     * 加载模型配置
     */
    fun loadModelConfig(): JSONObject? {
        return try {
            val configString = context.assets.open(CONFIG_FILE_NAME).bufferedReader().use { it.readText() }
            JSONObject(configString)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * 加载模型并初始化TextProcessingService
     */
    fun loadModel(textProcessingService: TextProcessingService): Boolean {
        try {
            // 检查模型文件是否已存在于内部存储
            val modelFile = File(context.filesDir, MODEL_FILE_NAME)
            
            if (!modelFile.exists()) {
                // 如果不存在，从assets复制到内部存储
                copyModelFromAssets(modelFile)
            }
            
            // 加载模型
            textProcessingService.loadModel(modelFile)
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    /**
     * 从assets复制模型文件到内部存储
     */
    @Throws(IOException::class)
    private fun copyModelFromAssets(modelFile: File) {
        context.assets.open(MODEL_FILE_NAME).use { inputStream ->
            FileOutputStream(modelFile).use { outputStream ->
                val buffer = ByteArray(4 * 1024) // 4KB buffer
                var read: Int
                while (inputStream.read(buffer).also { read = it } != -1) {
                    outputStream.write(buffer, 0, read)
                }
                outputStream.flush()
            }
        }
    }
} 