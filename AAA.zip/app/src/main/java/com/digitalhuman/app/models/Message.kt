package com.digitalhuman.app.models

import java.util.*

/**
 * 表示聊天中的一条消息
 */
data class Message(
    val id: String = UUID.randomUUID().toString(),
    val content: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
) 