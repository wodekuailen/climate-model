package com.digitalhuman.app.services

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.*

/**
 * 语音合成服务
 */
class SpeechSynthesisService(private val context: Context) {

    private var textToSpeech: TextToSpeech? = null
    private var isInitialized = false
    private var progressListener: UtteranceProgressListener? = null
    
    init {
        initializeTextToSpeech()
    }
    
    /**
     * 初始化文本到语音引擎
     */
    private fun initializeTextToSpeech() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = textToSpeech?.setLanguage(Locale.getDefault())
                isInitialized = (result != TextToSpeech.LANG_MISSING_DATA && 
                                result != TextToSpeech.LANG_NOT_SUPPORTED)
                
                // 设置进度监听器
                progressListener?.let { listener ->
                    textToSpeech?.setOnUtteranceProgressListener(listener)
                }
            }
        }
    }
    
    /**
     * 设置语音合成进度监听器
     */
    fun setProgressListener(listener: UtteranceProgressListener) {
        progressListener = listener
        textToSpeech?.setOnUtteranceProgressListener(listener)
    }
    
    /**
     * 播放文本
     */
    fun speak(text: String) {
        if (isInitialized && textToSpeech != null) {
            val utteranceId = UUID.randomUUID().toString()
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        }
    }
    
    /**
     * 停止播放
     */
    fun stop() {
        textToSpeech?.stop()
    }
    
    /**
     * 设置语速
     * @param speed 语速值，范围0.0-2.0，1.0为正常速度
     */
    fun setSpeechRate(speed: Float) {
        textToSpeech?.setSpeechRate(speed)
    }
    
    /**
     * 设置音调
     * @param pitch 音调值，范围0.0-2.0，1.0为正常音调
     */
    fun setPitch(pitch: Float) {
        textToSpeech?.setPitch(pitch)
    }
    
    /**
     * 释放资源
     */
    fun release() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
    }
} 