# 轻量级安卓数字人应用

这是一个轻量级的安卓数字人应用，支持语音和文字对话，可以连接自定义知识库。

## 功能特点

- 轻量级设计，占用资源少
- 支持语音对话和文字输入
- 可自定义数字人形象
- 支持连接外部知识库
- 离线运行核心功能

## 技术栈

- Android原生开发
- TensorFlow Lite用于模型推理
- WebRTC用于音频处理
- Room数据库存储本地知识库
- Retrofit用于API通信

## 项目结构

```
app/
├── src/
│   ├── main/
│   │   ├── java/com/digitalhuman/
│   │   │   ├── activities/       # 主要活动界面
│   │   │   ├── adapters/         # 适配器
│   │   │   ├── fragments/        # 界面片段
│   │   │   ├── models/           # 数据模型
│   │   │   ├── services/         # 后台服务
│   │   │   ├── utils/            # 工具类
│   │   │   └── viewmodels/       # 视图模型
│   │   └── res/                  # 资源文件
│   └── assets/                   # 模型文件和其他资源
├── build.gradle                  # 项目构建配置
└── proguard-rules.pro            # 混淆规则
```

## 安装要求

- Android 7.0 (API级别24)或更高版本
- 至少2GB RAM
- 至少100MB存储空间 