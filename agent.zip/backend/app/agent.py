from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolExecutor
from langchain_core.messages import ToolMessage, AIMessage, HumanMessage
from typing import TypedDict, List
from langchain_community.chat_models import ChatOllama
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.pydantic_v1 import BaseModel, Field
from langchain.tools import tool

# 导入我们自己实现的工具
from . import tools

# --- 1. 定义所有工具 ---
@tool
def search_knowledge_base(query: str) -> str:
    """在历史问题知识库中搜索相似的案例，用于获取初步灵感。"""
    return tools.kb.search_kb(query)

@tool
def query_codebase(query: str) -> str:
    """在代码库中通过 `git grep` 搜索关键字，用于寻找相关代码。"""
    return tools.query_codebase(query)

@tool
def read_file_content(file_path: str) -> str:
    """读取指定文件的内容，用于深入分析代码细节。"""
    return tools.read_file_content(file_path)

@tool
def git_blame(file_path: str, line_number: int) -> str:
    """对指定文件的指定行运行 `git blame`，用于追踪代码修改历史。"""
    return tools.git_blame(file_path, line_number)

@tool
def query_database_status(db_name: str) -> str:
    """查询指定数据库的健康状态 (模拟)。"""
    return tools.query_database_status(db_name)

@tool
def update_jira_ticket(ticket_id: str, comment: str) -> str:
    """向 Jira Ticket 添加评论 (模拟)。"""
    return tools.update_jira_ticket(ticket_id, comment)

# 这个工具不暴露给 LLM，由我们自己调用
def add_to_knowledge_base(problem: str, analysis_summary: str):
    """将成功的分析案例存入知识库。"""
    return tools.kb.add_to_kb(problem, analysis_summary)

# 创建一个工具执行器
tool_executor = ToolExecutor([
    search_knowledge_base, query_codebase, read_file_content, 
    git_blame, query_database_status, update_jira_ticket
])

# --- 2. 定义 LLM 和 Agent 状态 ---
class AgentState(TypedDict):
    problem_description: str
    messages: List # 用于存储对话历史，包括工具调用和返回
    analysis_summary: str # 用于存储最终的分析摘要

# 我们需要一个能调用工具的 LLM
llm = ChatOllama(model="qwen2.5:7b", temperature=0).bind_tools(tool_executor.tools)

# --- 3. 定义图的节点 ---
def entry_node(state: AgentState):
    """图的入口：先搜索知识库"""
    initial_query = state["problem_description"]
    kb_result = search_knowledge_base.invoke({"query": initial_query})
    message = HumanMessage(
        content=f"已在知识库中搜索相似案例，结果如下：\n---\n{kb_result}\n---\n现在，请根据以上信息和我最初的问题，开始分析并制定下一步计划。"
    )
    return {"messages": [message]}

def planning_node(state: AgentState):
    """规划节点：根据当前状态，让 LLM 决定下一步"""
    prompt = ChatPromptTemplate.from_messages([
        ("system", """
        你是一名顶级的软件故障诊断专家，你的任务是分析并解决用户提出的问题。
        你会按步骤思考，使用工具收集信息，直到找到问题的根源。
        - **思考**: 根据现有信息，分析情况，提出假设。
        - **行动**: 如果需要更多信息，选择一个最合适的工具来调用。
        - **总结**: 如果信息足够，请输出你的最终分析报告，并以 "FINAL ANSWER:" 开头。
        """),
        ("placeholder", "{messages}")
    ])
    chain = prompt | llm
    response = chain.invoke({"messages": state["messages"]})
    return {"messages": [response]}

def tool_execution_node(state: AgentState):
    """工具执行节点"""
    tool_invocation = state["messages"][-1].tool_calls[0]
    tool_output = tool_executor.invoke([tool_invocation])
    # 将工具的输出以 ToolMessage 的形式加回消息列表
    tool_message = ToolMessage(content=str(tool_output), tool_call_id=tool_invocation['id'])
    return {"messages": [tool_message]}

def final_summary_node(state: AgentState):
    """在结束前生成最终的分析摘要"""
    summary = "\n".join([f"[{msg.type}] {msg.content}" for msg in state["messages"]])
    final_report = f"问题：{state['problem_description']}\n\n分析全过程回顾：\n{summary}"
    # 调用内部工具，将经验存入知识库
    add_to_knowledge_base(state['problem_description'], final_report)
    print("---已将本次分析存入知识库---")
    return {"analysis_summary": final_report}

# --- 4. 定义图的路由逻辑 ---
def router_node(state: AgentState):
    """决策节点"""
    last_message = state["messages"][-1]
    if last_message.tool_calls:
        return "execute_tool"
    if "FINAL ANSWER:" in last_message.content:
        return "summarize"
    return "plan"

# --- 5. 构建图 ---
def create_agent_graph():
    workflow = StateGraph(AgentState)
    
    workflow.add_node("entry", entry_node)
    workflow.add_node("plan", planning_node)
    workflow.add_node("execute_tool", tool_execution_node)
    workflow.add_node("summarize", final_summary_node)

    workflow.set_entry_point("entry")
    workflow.add_edge("entry", "plan")
    
    workflow.add_conditional_edges(
        "plan",
        router_node,
        {"execute_tool": "execute_tool", "summarize": "summarize", "plan": "plan"}
    )
    workflow.add_conditional_edges(
        "execute_tool",
        router_node,
        {"plan": "plan", "summarize": "summarize"}
    )
    
    workflow.add_edge("summarize", END)
    
    return workflow.compile()

# 示例用法
if __name__ == '__main__':
    graph = create_agent_graph()
    initial_input = {"problem_description": "生产环境数据库写入失败", "messages": []}
    for event in graph.stream(initial_input):
        for key, value in event.items():
            print(f"节点: {key}")
            print("---")
            print(value)
        print("\n=================\n") 