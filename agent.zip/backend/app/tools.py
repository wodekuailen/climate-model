# 这个文件将包含 Agent 可以调用的所有工具
# 例如：查询代码库、运行 git blame、查询 Jira、更新知识库等

import subprocess
import os
import requests
import json
from langchain_community.vectorstores import Milvus
from langchain_community.embeddings import OllamaEmbeddings
from langchain_text_splitters import CharacterTextSplitter

# --- 配置区 ---
# TODO: 请将此路径替换为您本地真实的代码仓库路径
CODE_REPO_PATH = "D:/your/code/repo/path" 
# Jira 和数据库的模拟配置
JIRA_API_URL = "https://your-jira-instance.com/rest/api/2/issue/"
JIRA_AUTH = ("your-email@example.com", "your-api-token")
DB_STATUS_ENDPOINT = "http://localhost:8080/db/health"
# Milvus 配置
MILVUS_HOST = "localhost"
MILVUS_PORT = "19530"
KB_COLLECTION_NAME = "problem_knowledge_base"
# --- 配置区结束 ---


class ToolError(Exception):
    """自定义工具执行异常"""
    pass


# --- 知识库模块 ---
class KnowledgeBase:
    def __init__(self):
        self.embeddings = OllamaEmbeddings(model="qwen2.5:7b")
        self.vector_store = Milvus(
            embedding_function=self.embeddings,
            connection_args={"host": MILVUS_HOST, "port": MILVUS_PORT},
            collection_name=KB_COLLECTION_NAME,
        )

    def add_to_kb(self, problem: str, analysis: str):
        text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
        docs = text_splitter.create_documents([f"问题: {problem}\n分析过程与结论:\n{analysis}"])
        self.vector_store.add_documents(docs)
        return "知识库添加成功。"

    def search_kb(self, query: str):
        try:
            docs = self.vector_store.similarity_search(query, k=2)
            if not docs:
                return "在知识库中未找到相似案例。"
            return "\n---\n".join([doc.page_content for doc in docs])
        except Exception as e:
            return f"知识库搜索失败: {e}"

# 实例化知识库
kb = KnowledgeBase()

# --- Git 和文件工具 ---
def _run_command(command: list[str], working_dir: str) -> str:
    """通用命令执行函数"""
    if not os.path.isdir(working_dir):
        raise ToolError(f"错误：代码仓库路径 '{working_dir}' 不存在或不是一个目录。")
    
    try:
        # 使用 text=True 让输出为字符串，并指定编码
        # capture_output=True 捕获标准输出和标准错误
        result = subprocess.run(
            command,
            cwd=working_dir,
            check=True,
            text=True,
            capture_output=True,
            encoding='utf-8'
        )
        if result.stdout:
            return result.stdout
        return "命令执行成功，但没有输出。"
    except FileNotFoundError:
        raise ToolError(f"错误：命令 '{command[0]}' 未找到。请确保 Git 已经安装并被添加到了系统的 PATH 环境变量中。")
    except subprocess.CalledProcessError as e:
        # 如果命令返回非零退出码，说明出错了
        error_message = f"命令执行失败，返回码 {e.returncode}。\n"
        if e.stdout:
            error_message += f"输出:\n{e.stdout}\n"
        if e.stderr:
            error_message += f"错误信息:\n{e.stderr}\n"
        raise ToolError(error_message)


def query_codebase(query: str) -> str:
    """
    在代码库中通过 `git grep` 命令搜索关键字。
    """
    print(f"🔍 正在代码库中搜索: '{query}'")
    command = ["git", "grep", "-n", query] # -n 显示行号
    try:
        return _run_command(command, CODE_REPO_PATH)
    except ToolError as e:
        return str(e)


def git_blame(file_path: str, line_number: int) -> str:
    """
    对指定文件的指定行运行 `git blame`，查找最近的修改。
    """
    print(f" blaming '{file_path}' at line {line_number}...")
    # -L <start>,<end> 限制 blame 的行号范围
    command = ["git", "blame", f"-L{line_number},{line_number}", "--", file_path]
    try:
        return _run_command(command, CODE_REPO_PATH)
    except ToolError as e:
        return str(e)


def read_file_content(file_path: str) -> str:
    """读取指定文件的内容。"""
    print(f"📄 正在读取文件: {file_path}")
    full_path = os.path.join(CODE_REPO_PATH, file_path)
    if not os.path.exists(full_path):
        return f"错误：文件 '{file_path}' 在代码仓库中不存在。"
    try:
        with open(full_path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        return f"读取文件失败: {e}"


# --- 外部服务工具 (模拟) ---
def query_database_status(db_name: str) -> str:
    """查询指定数据库的健康状态 (模拟)。"""
    print(f"🗄️ 查询数据库 '{db_name}' 状态...")
    try:
        response = requests.get(DB_STATUS_ENDPOINT, params={"db": db_name}, timeout=5)
        response.raise_for_status()
        return json.dumps(response.json(), indent=2)
    except requests.RequestException as e:
        return f"查询数据库状态失败 (模拟): {e}。这可能是因为模拟的健康检查端点未运行。"


def update_jira_ticket(ticket_id: str, comment: str) -> str:
    """向 Jira Ticket 添加评论 (模拟)。"""
    print(f"📝 向 Jira Ticket '{ticket_id}' 添加评论...")
    payload = {"body": comment}
    try:
        # 这是一个模拟请求，它会失败，但能演示其工作方式
        response = requests.post(f"{JIRA_API_URL}{ticket_id}/comment", json=payload, auth=JIRA_AUTH, timeout=10)
        response.raise_for_status()
        return f"成功向 Jira Ticket {ticket_id} 添加了评论。"
    except requests.RequestException as e:
        return f"更新 Jira 失败 (模拟): {e}。这是一个预期中的模拟失败。"


def update_knowledge_base(problem: str, solution: str) -> bool:
    """
    将问题和解决方案更新到 Milvus 知识库。
    这是一个模拟函数。
    """
    print(f"正在更新知识库...")
    print(f"问题: {problem}")
    print(f"解决方案: {solution}")
    print("知识库更新成功。")
    return True 