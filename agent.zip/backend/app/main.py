from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import json

# 假设 agent.py 和 tools.py 在同一个目录下
from .agent import create_agent_graph

app = FastAPI(
    title="Problem Analysis Agent API",
    description="API for interacting with the LangGraph-based analysis agent.",
    version="0.1.0",
)

# 配置 CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 允许所有来源，为了开发的便利性
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 编译好的 LangGraph 应用实例
agent_graph = create_agent_graph()

@app.websocket("/ws/analyze")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            # 等待客户端发送问题描述
            data = await websocket.receive_text()
            payload = json.loads(data)
            problem_description = payload.get("problem_description")

            if not problem_description:
                await websocket.send_json({"type": "error", "data": "Problem description is required."})
                continue
            
            # 初始化 Agent 的输入，现在使用 messages 列表
            initial_input = {"problem_description": problem_description, "messages": []}

            # 流式处理 Agent 的每一步
            async for event in agent_graph.astream(initial_input):
                for key, value in event.items():
                    # 将每一步的结果发送给前端
                    await websocket.send_json({
                        "type": "log",
                        "node": key,
                        "data": { "messages": [m.dict() for m in value['messages']] }
                    })
            
            # 标志分析结束
            await websocket.send_json({"type": "end", "data": "Analysis complete."})

    except WebSocketDisconnect:
        print("Client disconnected")
    except Exception as e:
        print(f"An error occurred: {e}")
        await websocket.send_json({"type": "error", "data": str(e)})


@app.get("/")
def read_root():
    return {"message": "Welcome to the Problem Analysis Agent API"} 