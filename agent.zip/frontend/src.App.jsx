import { useState, useEffect, useRef } from 'react';
import './App.css';

function App() {
  const [problem, setProblem] = useState('');
  const [analysisLog, setAnalysisLog] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const ws = useRef(null);

  useEffect(() => {
    // 组件卸载时关闭 WebSocket 连接
    return () => {
      if (ws.current) {
        ws.current.close();
      }
    };
  }, []);

  const handleAnalyze = () => {
    if (!problem.trim()) {
      alert('请输入问题描述');
      return;
    }
    
    if (ws.current && ws.current.readyState === WebSocket.OPEN) {
      ws.current.close();
    }

    ws.current = new WebSocket('ws://localhost:8000/ws/analyze');

    ws.current.onopen = () => {
      setIsLoading(true);
      setAnalysisLog([`>> 开始分析: ${problem}`]);
      ws.current.send(JSON.stringify({ problem_description: problem }));
    };

    ws.current.onmessage = (event) => {
      const message = JSON.parse(event.data);
      
      if (message.type === 'log') {
        const { node, data } = message;
        const logEntry = `[${node}] ${JSON.stringify(data.log.slice(-1)[0] || data, null, 2)}`;
        setAnalysisLog(prevLog => [...prevLog, logEntry]);
      } else if (message.type === 'end') {
        setAnalysisLog(prevLog => [...prevLog, `>> ${message.data}`]);
        setIsLoading(false);
        ws.current.close();
      } else if (message.type === 'error') {
        setAnalysisLog(prevLog => [...prevLog, `[错误] ${message.data}`]);
        setIsLoading(false);
      }
    };

    ws.current.onclose = () => {
      setIsLoading(false);
      console.log('WebSocket 连接已关闭');
    };

    ws.current.onerror = (error) => {
      console.error('WebSocket 错误:', error);
      setAnalysisLog(prevLog => [...prevLog, '[严重错误] WebSocket 连接失败']);
      setIsLoading(false);
    };
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>高级问题分析 Agent</h1>
        <p>基于 LangGraph、Ollama 和 Milvus</p>
      </header>
      <main>
        <div className="analysis-form">
          <textarea
            value={problem}
            onChange={(e) => setProblem(e.target.value)}
            placeholder="请详细描述您遇到的问题，例如：生产环境数据库写入失败，日志显示 'Connection refused'..."
            rows="4"
            disabled={isLoading}
          />
          <button onClick={handleAnalyze} disabled={isLoading}>
            {isLoading ? '分析中...' : '开始分析'}
          </button>
        </div>
        <div className="analysis-results">
          <h2>分析过程</h2>
          <div className="log-container">
            {analysisLog.map((log, index) => (
              <p key={index} className="log-entry">{log}</p>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App; 