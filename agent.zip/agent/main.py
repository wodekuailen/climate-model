"""
主程序入口，用于启动智能分析Agent
"""
import os
import argparse
import json
import logging
from pathlib import Path
from dotenv import load_dotenv

from agent.core import AnalysisAgent
from config.config import (
    MODEL_PROVIDER, OPENAI_API_KEY, OPENAI_MODEL,
    OLLAMA_HOST, OLLAMA_MODEL,
    JIRA_URL, JIRA_USERNAME, JIRA_API_TOKEN,
    CODE_REPOSITORY_PATH
)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("agent.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="智能分析Agent")
    
    # 分析模式
    parser.add_argument("--mode", choices=["log", "jira", "interactive"], default="interactive",
                      help="分析模式：log(分析日志文件), jira(分析Jira问题), interactive(交互模式)")
    
    # 日志文件路径
    parser.add_argument("--log-file", type=str, help="日志文件路径")
    
    # Jira问题键
    parser.add_argument("--jira-key", type=str, help="Jira问题键")
    
    # 代码仓库路径
    parser.add_argument("--repo-path", type=str, default=CODE_REPOSITORY_PATH,
                      help="代码仓库路径")
    
    # 知识库路径
    parser.add_argument("--kb-path", type=str, default="./knowledge_base",
                      help="知识库路径")
    
    # 输出文件路径
    parser.add_argument("--output", type=str, help="输出文件路径")
    
    # 模型提供商
    parser.add_argument("--model-provider", type=str, choices=["openai", "ollama"], default=MODEL_PROVIDER,
                      help="模型提供商: openai或ollama")
    
    # 模型名称
    parser.add_argument("--model", type=str, help="语言模型名称")
    
    # Ollama主机地址
    parser.add_argument("--ollama-host", type=str, default=OLLAMA_HOST,
                      help="Ollama主机地址")
    
    return parser.parse_args()

def analyze_log_file(agent: AnalysisAgent, log_file_path: str):
    """分析日志文件"""
    try:
        with open(log_file_path, 'r', encoding='utf-8') as f:
            log_content = f.read()
        
        logger.info(f"正在分析日志文件: {log_file_path}")
        result = agent.analyze_log(log_content)
        return result
    except Exception as e:
        logger.error(f"分析日志文件时出错: {e}")
        return {"error": str(e)}

def analyze_jira_issue(agent: AnalysisAgent, issue_key: str):
    """分析Jira问题"""
    try:
        logger.info(f"正在分析Jira问题: {issue_key}")
        result = agent.analyze_jira_issue(issue_key)
        return result
    except Exception as e:
        logger.error(f"分析Jira问题时出错: {e}")
        return {"error": str(e)}

def interactive_mode(agent: AnalysisAgent):
    """交互模式"""
    print("欢迎使用智能分析Agent（交互模式）")
    print("输入 'exit' 或 'quit' 退出")
    
    while True:
        print("\n请选择操作:")
        print("1. 分析日志")
        print("2. 分析Jira问题")
        print("3. 退出")
        
        choice = input("请输入选项编号: ")
        
        if choice == "1":
            log_path = input("请输入日志文件路径（或直接粘贴日志内容）: ")
            
            if os.path.exists(log_path):
                # 如果是文件路径，读取文件内容
                with open(log_path, 'r', encoding='utf-8') as f:
                    log_content = f.read()
            else:
                # 否则将输入视为日志内容
                log_content = log_path
            
            result = agent.analyze_log(log_content)
            print("\n分析结果:")
            print(json.dumps(result, ensure_ascii=False, indent=2))
            
            # 询问是否保存结果
            save = input("\n是否保存分析结果？(y/n): ")
            if save.lower() == 'y':
                output_path = input("请输入保存路径: ")
                with open(output_path, 'w', encoding='utf-8') as f:
                    json.dump(result, f, ensure_ascii=False, indent=2)
                print(f"结果已保存到 {output_path}")
        
        elif choice == "2":
            issue_key = input("请输入Jira问题键: ")
            result = agent.analyze_jira_issue(issue_key)
            print("\n分析结果:")
            print(json.dumps(result, ensure_ascii=False, indent=2))
            
            # 询问是否保存结果
            save = input("\n是否保存分析结果？(y/n): ")
            if save.lower() == 'y':
                output_path = input("请输入保存路径: ")
                with open(output_path, 'w', encoding='utf-8') as f:
                    json.dump(result, f, ensure_ascii=False, indent=2)
                print(f"结果已保存到 {output_path}")
        
        elif choice == "3" or choice.lower() in ["exit", "quit"]:
            print("感谢使用，再见！")
            break
        
        else:
            print("无效的选项，请重新输入")

def main():
    """主函数"""
    # 加载环境变量
    load_dotenv()
    
    # 解析命令行参数
    args = parse_args()
    
    # 配置Jira
    jira_config = None
    if JIRA_URL and JIRA_USERNAME and JIRA_API_TOKEN:
        jira_config = {
            "url": JIRA_URL,
            "username": JIRA_USERNAME,
            "api_token": JIRA_API_TOKEN
        }
    
    # 确保代码仓库路径存在
    repo_path = args.repo_path
    if not os.path.exists(repo_path):
        logger.warning(f"代码仓库路径不存在: {repo_path}")
        repo_path = input("请输入有效的代码仓库路径: ")
        if not os.path.exists(repo_path):
            logger.error("无效的代码仓库路径")
            return
    
    # 初始化Agent
    agent = AnalysisAgent(
        repo_path=repo_path,
        jira_config=jira_config,
        model_provider=args.model_provider,
        model_name=args.model,
        api_key=OPENAI_API_KEY,
        ollama_host=args.ollama_host,
        knowledge_base_path=args.kb_path
    )
    
    result = None
    
    # 根据模式执行不同的操作
    if args.mode == "log":
        if not args.log_file:
            logger.error("未指定日志文件路径")
            return
        result = analyze_log_file(agent, args.log_file)
    
    elif args.mode == "jira":
        if not args.jira_key:
            logger.error("未指定Jira问题键")
            return
        result = analyze_jira_issue(agent, args.jira_key)
    
    elif args.mode == "interactive":
        interactive_mode(agent)
        return
    
    # 输出结果
    if result:
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            logger.info(f"结果已保存到 {args.output}")
        else:
            print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main() 