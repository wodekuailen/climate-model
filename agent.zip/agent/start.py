"""
启动脚本，用于启动整个智能分析Agent系统
"""
import os
import sys
import time
import subprocess
import logging
import argparse
import webbrowser
from pathlib import Path

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="启动智能分析Agent系统")
    
    parser.add_argument("--no-milvus", action="store_true", help="不启动Milvus服务（如果已经有运行的实例）")
    parser.add_argument("--port", type=int, default=8000, help="Web服务端口，默认为8000")
    parser.add_argument("--host", type=str, default="127.0.0.1", help="Web服务主机，默认为127.0.0.1")
    parser.add_argument("--no-browser", action="store_true", help="不自动打开浏览器")
    
    return parser.parse_args()

def check_dependencies():
    """检查依赖"""
    try:
        import uvicorn
        import fastapi
        import langchain
        import langgraph
        logger.info("核心依赖检查通过")
    except ImportError as e:
        logger.error(f"缺少依赖: {e}")
        logger.info("请先运行: pip install -r requirements.txt")
        return False
    
    # 检查Milvus依赖
    try:
        import pymilvus
        logger.info("Milvus依赖检查通过")
    except ImportError:
        logger.warning("未安装pymilvus，将无法使用Milvus向量数据库")
        logger.info("如需使用Milvus，请运行: pip install pymilvus")
    
    return True

def check_milvus_running():
    """检查Milvus是否正在运行"""
    try:
        import pymilvus
        from pymilvus import connections
        
        connections.connect("default", host="localhost", port="19530")
        connections.disconnect("default")
        logger.info("Milvus服务已连接")
        return True
    except Exception:
        logger.warning("无法连接到Milvus服务")
        return False

def start_milvus():
    """启动Milvus服务（假设使用Docker）"""
    try:
        # 检查Docker是否安装
        docker_check = subprocess.run(["docker", "--version"], capture_output=True, text=True)
        if docker_check.returncode != 0:
            logger.error("未检测到Docker，请安装Docker后再试")
            logger.info("Milvus安装指南: https://milvus.io/docs/install_standalone-docker.md")
            return False
        
        # 检查Milvus容器是否存在
        container_check = subprocess.run(
            ["docker", "ps", "-a", "--filter", "name=milvus-standalone", "--format", "{{.Names}}"],
            capture_output=True, text=True
        )
        
        if "milvus-standalone" in container_check.stdout:
            # 容器已存在，启动它
            logger.info("Milvus容器已存在，正在启动...")
            subprocess.run(["docker", "start", "milvus-standalone"], check=True)
        else:
            # 拉取并启动Milvus
            logger.info("正在拉取并启动Milvus...")
            
            # 创建卷目录
            volumes_dir = Path("./milvus_data")
            volumes_dir.mkdir(exist_ok=True)
            
            # 启动Milvus
            subprocess.run([
                "docker", "run", "-d",
                "--name", "milvus-standalone",
                "-p", "19530:19530",
                "-p", "9091:9091",
                "-v", f"{volumes_dir.absolute()}/db:/var/lib/milvus/db",
                "-v", f"{volumes_dir.absolute()}/conf:/var/lib/milvus/conf",
                "-v", f"{volumes_dir.absolute()}/logs:/var/lib/milvus/logs",
                "-v", f"{volumes_dir.absolute()}/wal:/var/lib/milvus/wal",
                "milvusdb/milvus:latest",
                "standalone"
            ], check=True)
        
        # 等待Milvus启动
        logger.info("等待Milvus服务启动...")
        for _ in range(30):  # 最多等待30秒
            if check_milvus_running():
                logger.info("Milvus服务已成功启动")
                return True
            time.sleep(1)
        
        logger.error("Milvus服务启动超时")
        return False
    except subprocess.CalledProcessError as e:
        logger.error(f"启动Milvus失败: {e}")
        return False
    except Exception as e:
        logger.error(f"启动Milvus时发生错误: {e}")
        return False

def start_web_service(host, port):
    """启动Web服务"""
    try:
        # 确保static目录存在
        os.makedirs("static", exist_ok=True)
        
        # 启动FastAPI服务
        import uvicorn
        logger.info(f"正在启动Web服务，地址: http://{host}:{port}")
        uvicorn.run("api:app", host=host, port=port, reload=True)
        return True
    except Exception as e:
        logger.error(f"启动Web服务失败: {e}")
        return False

def main():
    """主函数"""
    args = parse_args()
    
    # 检查依赖
    if not check_dependencies():
        return
    
    # 启动Milvus（如果需要）
    if not args.no_milvus:
        if not check_milvus_running():
            if not start_milvus():
                logger.warning("无法启动Milvus服务，将使用文件系统作为备用存储")
    
    # 打开浏览器（如果需要）
    if not args.no_browser:
        url = f"http://{args.host}:{args.port}"
        logger.info(f"正在打开浏览器: {url}")
        webbrowser.open(url)
    
    # 启动Web服务
    start_web_service(args.host, args.port)

if __name__ == "__main__":
    main() 