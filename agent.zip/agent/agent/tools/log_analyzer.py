"""
日志分析工具，用于分析日志中的异常信息
"""
import re
from typing import Dict, List, Optional, Tuple

class LogAnalyzer:
    """日志分析工具类，用于从日志中提取异常信息和关键模式"""
    
    def __init__(self):
        # 常见异常模式的正则表达式
        self.patterns = {
            "database_error": r"(database|DB|sql|query).*?(error|exception|failure|failed|timeout)",
            "network_error": r"(network|connection|timeout|refused).*?(error|exception|failure|failed)",
            "memory_error": r"(memory|heap|stack|out\s+of\s+memory).*?(error|exception|overflow|full)",
            "permission_error": r"(permission|access|denied|unauthorized).*?(error|exception|failure|failed)",
            "null_pointer": r"(null\s+pointer|NullPointerException|NPE|null\s+reference)",
            "file_error": r"(file|io|input|output).*?(error|exception|not\s+found|missing)"
        }
    
    def analyze_log(self, log_content: str) -> Dict:
        """
        分析日志内容，提取异常信息
        
        Args:
            log_content: 日志内容字符串
            
        Returns:
            包含分析结果的字典
        """
        result = {
            "exceptions": self._extract_exceptions(log_content),
            "error_patterns": self._identify_error_patterns(log_content),
            "stack_traces": self._extract_stack_traces(log_content),
            "timestamps": self._extract_timestamps(log_content)
        }
        
        return result
    
    def _extract_exceptions(self, log_content: str) -> List[str]:
        """提取日志中的异常信息"""
        # 匹配常见的异常模式，如Exception:, Error:, Caused by: 等
        exception_pattern = r"(?:Exception|Error|Failure|Caused by):\s+([^\n]+)"
        matches = re.findall(exception_pattern, log_content, re.IGNORECASE)
        return matches
    
    def _identify_error_patterns(self, log_content: str) -> Dict[str, List[str]]:
        """识别日志中的错误模式"""
        results = {}
        for pattern_name, pattern in self.patterns.items():
            matches = re.findall(pattern, log_content, re.IGNORECASE)
            if matches:
                results[pattern_name] = matches
        return results
    
    def _extract_stack_traces(self, log_content: str) -> List[str]:
        """提取日志中的堆栈跟踪信息"""
        # 简单的堆栈跟踪提取，可能需要根据实际日志格式调整
        stack_pattern = r"at\s+([a-zA-Z0-9_$.]+\([^)]*\))"
        matches = re.findall(stack_pattern, log_content)
        return matches
    
    def _extract_timestamps(self, log_content: str) -> List[str]:
        """提取日志中的时间戳"""
        # 匹配常见的时间戳格式
        timestamp_pattern = r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?"
        matches = re.findall(timestamp_pattern, log_content)
        return matches
    
    def find_related_code_components(self, stack_traces: List[str]) -> List[str]:
        """
        从堆栈跟踪中识别相关的代码组件
        
        Args:
            stack_traces: 堆栈跟踪列表
            
        Returns:
            可能相关的代码组件列表
        """
        components = []
        for trace in stack_traces:
            # 提取类名和包名
            match = re.search(r"([a-zA-Z0-9_$.]+)\.([a-zA-Z0-9_$]+)\(", trace)
            if match:
                full_path = match.group(1)
                method = match.group(2)
                components.append(f"{full_path}.{method}")
        
        return components 