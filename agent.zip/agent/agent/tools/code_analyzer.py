"""
代码分析工具，用于分析代码库中的相关组件
"""
import os
import re
from typing import Dict, List, Optional, Set
from pathlib import Path

class CodeAnalyzer:
    """代码分析工具类，用于分析代码库中的相关组件"""
    
    def __init__(self, repo_path: str):
        """
        初始化代码分析工具
        
        Args:
            repo_path: 代码库路径
        """
        self.repo_path = Path(repo_path)
        
        # 支持的文件类型及其对应的注释符号
        self.file_extensions = {
            ".java": {"single_line": "//", "multi_line_start": "/*", "multi_line_end": "*/"},
            ".py": {"single_line": "#", "multi_line_start": '"""', "multi_line_end": '"""'},
            ".js": {"single_line": "//", "multi_line_start": "/*", "multi_line_end": "*/"},
            ".ts": {"single_line": "//", "multi_line_start": "/*", "multi_line_end": "*/"},
            ".go": {"single_line": "//", "multi_line_start": "/*", "multi_line_end": "*/"},
            ".cs": {"single_line": "//", "multi_line_start": "/*", "multi_line_end": "*/"},
            ".cpp": {"single_line": "//", "multi_line_start": "/*", "multi_line_end": "*/"},
            ".c": {"single_line": "//", "multi_line_start": "/*", "multi_line_end": "*/"},
        }
    
    def find_files_by_component(self, component_name: str) -> List[str]:
        """
        根据组件名查找相关文件
        
        Args:
            component_name: 组件名，如com.example.service.UserService
            
        Returns:
            相关文件的路径列表
        """
        # 将组件名转换为可能的文件路径
        parts = component_name.split('.')
        possible_file_names = []
        
        # 处理Java风格的包名
        if len(parts) > 1:
            class_name = parts[-1]
            package_path = '/'.join(parts[:-1])
            possible_file_names.append(f"{package_path}/{class_name}.java")
            possible_file_names.append(f"{package_path}/{class_name}.py")
            possible_file_names.append(f"{package_path}/{class_name}.js")
            possible_file_names.append(f"{package_path}/{class_name}.ts")
        
        # 添加简单的文件名匹配
        for part in parts:
            possible_file_names.append(f"**/*{part}*.java")
            possible_file_names.append(f"**/*{part}*.py")
            possible_file_names.append(f"**/*{part}*.js")
            possible_file_names.append(f"**/*{part}*.ts")
        
        # 查找匹配的文件
        found_files = []
        for pattern in possible_file_names:
            for file_path in self.repo_path.glob(pattern):
                if file_path.is_file() and file_path not in found_files:
                    found_files.append(str(file_path))
        
        return found_files
    
    def search_code_by_pattern(self, pattern: str, file_extensions: Optional[List[str]] = None) -> Dict[str, List[str]]:
        """
        在代码库中搜索匹配模式的代码
        
        Args:
            pattern: 正则表达式模式
            file_extensions: 要搜索的文件扩展名列表，如['.java', '.py']
            
        Returns:
            匹配结果的字典，键为文件路径，值为匹配的行列表
        """
        if file_extensions is None:
            file_extensions = list(self.file_extensions.keys())
        
        results = {}
        
        for ext in file_extensions:
            for file_path in self.repo_path.glob(f"**/*{ext}"):
                if not file_path.is_file():
                    continue
                
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        
                    matches = re.findall(pattern, content, re.MULTILINE)
                    if matches:
                        # 提取匹配行的上下文
                        lines = content.split('\n')
                        matched_lines = []
                        
                        for i, line in enumerate(lines):
                            if re.search(pattern, line):
                                # 添加匹配行及其上下文（前后各1行）
                                context = []
                                if i > 0:
                                    context.append(f"{i}: {lines[i-1]}")
                                context.append(f"{i+1}: {line}")
                                if i < len(lines) - 1:
                                    context.append(f"{i+2}: {lines[i+1]}")
                                
                                matched_lines.append('\n'.join(context))
                        
                        results[str(file_path)] = matched_lines
                except Exception as e:
                    print(f"Error reading file {file_path}: {e}")
        
        return results
    
    def analyze_database_operations(self, file_path: str) -> Dict:
        """
        分析文件中的数据库操作
        
        Args:
            file_path: 文件路径
            
        Returns:
            数据库操作分析结果
        """
        # 数据库操作相关的模式
        db_patterns = {
            "sql_query": r"(?:SELECT|INSERT|UPDATE|DELETE|CREATE|ALTER|DROP)\s+.+?(?:FROM|INTO|TABLE|DATABASE|SCHEMA)\s+\w+",
            "jdbc_connection": r"(?:getConnection|createConnection|DriverManager\.getConnection)\s*\(",
            "orm_query": r"(?:createQuery|createNativeQuery|find\w+By\w+|save|update|delete)\s*\(",
            "transaction": r"(?:@Transactional|beginTransaction|commit|rollback)\b"
        }
        
        results = {}
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            for pattern_name, pattern in db_patterns.items():
                matches = re.findall(pattern, content, re.IGNORECASE)
                if matches:
                    results[pattern_name] = matches
        except Exception as e:
            print(f"Error analyzing database operations in {file_path}: {e}")
        
        return results
    
    def extract_method_info(self, file_path: str, method_name: Optional[str] = None) -> List[Dict]:
        """
        提取文件中的方法信息
        
        Args:
            file_path: 文件路径
            method_name: 可选的方法名过滤
            
        Returns:
            方法信息列表
        """
        # 不同语言的方法定义模式
        method_patterns = {
            ".java": r"(?:public|protected|private|static|\s) +[\w\<\>\[\]]+\s+(\w+) *\([^\)]*\) *\{?",
            ".py": r"def\s+(\w+)\s*\([^\)]*\):",
            ".js": r"(?:function\s+(\w+)\s*\([^\)]*\)|(?:const|let|var)\s+(\w+)\s*=\s*(?:function|\([^\)]*\)\s*=>))",
            ".ts": r"(?:function\s+(\w+)\s*\([^\)]*\)|(?:const|let|var)\s+(\w+)\s*=\s*(?:function|\([^\)]*\)\s*=>)|(?:public|private|protected)\s+(\w+)\s*\([^\)]*\))"
        }
        
        ext = Path(file_path).suffix
        if ext not in method_patterns:
            return []
        
        methods = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            pattern = method_patterns.get(ext)
            if not pattern:
                return []
            
            # 查找所有方法定义
            matches = re.finditer(pattern, content)
            for match in matches:
                # 提取方法名
                method = None
                for group in match.groups():
                    if group:
                        method = group
                        break
                
                if not method or (method_name and method != method_name):
                    continue
                
                # 提取方法上下文
                start_pos = match.start()
                # 简单地提取方法定义后的200个字符作为上下文
                context = content[start_pos:start_pos + 200]
                
                methods.append({
                    "name": method,
                    "signature": match.group(0),
                    "context": context
                })
        except Exception as e:
            print(f"Error extracting method info from {file_path}: {e}")
        
        return methods 