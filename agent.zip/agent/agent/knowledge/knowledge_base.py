"""
知识库模块，使用Milvus向量数据库存储和检索分析结果
"""
import json
import logging
from typing import Dict, List, Any, Optional
from pathlib import Path
import os
import time

from pymilvus import (
    connections,
    utility,
    FieldSchema, CollectionSchema, DataType,
    Collection,
)

from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Milvus

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class KnowledgeBase:
    """基于Milvus的知识库，用于存储和检索分析结果"""
    
    def __init__(self, 
                base_path: str = "./knowledge_base",
                milvus_host: str = "localhost",
                milvus_port: str = "19530",
                collection_name: str = "analysis_results"):
        """
        初始化知识库
        
        Args:
            base_path: 知识库基础路径（用于存储非向量数据）
            milvus_host: Milvus服务器主机
            milvus_port: Milvus服务器端口
            collection_name: Milvus集合名称
        """
        self.base_path = Path(base_path)
        self.base_path.mkdir(exist_ok=True)
        
        self.collection_name = collection_name
        
        # 连接到Milvus
        try:
            connections.connect("default", host=milvus_host, port=milvus_port)
            logger.info(f"已连接到Milvus服务器: {milvus_host}:{milvus_port}")
            
            # 初始化集合
            self._init_collection()
            
            # 初始化向量存储
            self.embeddings = HuggingFaceEmbeddings(model_name="paraphrase-multilingual-MiniLM-L12-v2")
            self.vector_store = Milvus(
                collection_name=collection_name,
                embedding_function=self.embeddings,
                connection_args={"host": milvus_host, "port": milvus_port}
            )
            
            logger.info(f"知识库初始化完成: {collection_name}")
        except Exception as e:
            logger.warning(f"连接Milvus失败: {e}，将使用文件系统作为备用")
            self.vector_store = None
    
    def _init_collection(self):
        """初始化Milvus集合"""
        # 检查集合是否存在
        if utility.has_collection(self.collection_name):
            logger.info(f"集合已存在: {self.collection_name}")
            return
        
        # 定义集合字段
        fields = [
            FieldSchema(name="id", dtype=DataType.VARCHAR, is_primary=True, max_length=100),
            FieldSchema(name="issue_key", dtype=DataType.VARCHAR, max_length=50),
            FieldSchema(name="content", dtype=DataType.VARCHAR, max_length=65535),
            FieldSchema(name="issue_type", dtype=DataType.VARCHAR, max_length=50),
            FieldSchema(name="root_cause", dtype=DataType.VARCHAR, max_length=1000),
            FieldSchema(name="timestamp", dtype=DataType.VARCHAR, max_length=30),
            FieldSchema(name="embedding", dtype=DataType.FLOAT_VECTOR, dim=384)  # MiniLM模型的维度
        ]
        
        # 创建集合
        schema = CollectionSchema(fields, "分析结果知识库")
        collection = Collection(self.collection_name, schema)
        
        # 创建索引
        index_params = {
            "metric_type": "COSINE",
            "index_type": "IVF_FLAT",
            "params": {"nlist": 128}
        }
        collection.create_index("embedding", index_params)
        logger.info(f"已创建集合和索引: {self.collection_name}")
    
    def store_analysis(self, issue_key: str, analysis_data: Dict) -> bool:
        """
        存储分析结果到知识库
        
        Args:
            issue_key: 问题键
            analysis_data: 分析数据
            
        Returns:
            是否成功存储
        """
        try:
            # 提取关键信息
            conclusion = analysis_data.get("conclusion", {})
            root_cause = conclusion.get("root_cause", "未知根本原因")
            issue_type = conclusion.get("issue_type", "未分类")
            timestamp = analysis_data.get("timestamp", time.strftime("%Y-%m-%dT%H:%M:%SZ"))
            
            # 构建内容文本
            content = f"问题: {issue_key}\n根本原因: {root_cause}\n问题类型: {issue_type}"
            if "impact" in conclusion:
                content += f"\n影响范围: {conclusion['impact']}"
            if "solution" in conclusion:
                content += f"\n解决方案: {conclusion['solution']}"
            
            # 存储到文件系统（作为备份）
            file_path = self.base_path / f"{issue_key}.json"
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(analysis_data, f, ensure_ascii=False, indent=2)
            
            # 存储到Milvus
            if self.vector_store:
                try:
                    # 生成唯一ID
                    doc_id = f"{issue_key}_{int(time.time())}"
                    
                    # 添加到向量存储
                    self.vector_store.add_texts(
                        texts=[content],
                        metadatas=[{
                            "issue_key": issue_key,
                            "issue_type": issue_type,
                            "root_cause": root_cause,
                            "timestamp": timestamp
                        }],
                        ids=[doc_id]
                    )
                    logger.info(f"分析结果已存储到Milvus: {issue_key}")
                except Exception as e:
                    logger.error(f"存储到Milvus失败: {e}")
            
            return True
        except Exception as e:
            logger.error(f"存储分析结果时出错: {e}")
            return False
    
    def search_knowledge_base(self, query: str, top_k: int = 3) -> List[Dict]:
        """
        搜索知识库中的相关条目
        
        Args:
            query: 搜索查询
            top_k: 返回的最大结果数
            
        Returns:
            相关条目列表
        """
        results = []
        
        # 使用Milvus进行向量搜索
        if self.vector_store:
            try:
                docs_and_scores = self.vector_store.similarity_search_with_score(query, k=top_k)
                
                for doc, score in docs_and_scores:
                    # 从元数据中提取信息
                    metadata = doc.metadata
                    issue_key = metadata.get("issue_key", "未知")
                    
                    # 读取完整的分析结果
                    file_path = self.base_path / f"{issue_key}.json"
                    if file_path.exists():
                        with open(file_path, "r", encoding="utf-8") as f:
                            full_data = json.load(f)
                    else:
                        full_data = {}
                    
                    # 构建结果
                    result = {
                        "issue_key": issue_key,
                        "similarity_score": 1 - score,  # 转换余弦距离为相似度
                        "issue_type": metadata.get("issue_type", "未知"),
                        "root_cause": metadata.get("root_cause", "未知"),
                        "timestamp": metadata.get("timestamp", ""),
                        "full_data": full_data
                    }
                    
                    results.append(result)
                
                logger.info(f"从Milvus中找到 {len(results)} 个相关结果")
                return results
            except Exception as e:
                logger.error(f"Milvus搜索失败: {e}")
        
        # 如果Milvus不可用或搜索失败，回退到简单的文件系统搜索
        try:
            # 简单的关键词匹配
            all_files = list(self.base_path.glob("*.json"))
            matched_files = []
            
            for file_path in all_files:
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    
                    # 提取关键信息
                    conclusion = data.get("conclusion", {})
                    root_cause = conclusion.get("root_cause", "")
                    issue_type = conclusion.get("issue_type", "")
                    
                    # 简单的关键词匹配
                    match_text = f"{root_cause} {issue_type}".lower()
                    if query.lower() in match_text:
                        issue_key = file_path.stem
                        matched_files.append((issue_key, data, 0.5))  # 固定相似度为0.5
                except Exception:
                    continue
            
            # 取前top_k个结果
            for issue_key, data, score in matched_files[:top_k]:
                conclusion = data.get("conclusion", {})
                result = {
                    "issue_key": issue_key,
                    "similarity_score": score,
                    "issue_type": conclusion.get("issue_type", "未知"),
                    "root_cause": conclusion.get("root_cause", "未知"),
                    "timestamp": data.get("timestamp", ""),
                    "full_data": data
                }
                results.append(result)
            
            logger.info(f"从文件系统中找到 {len(results)} 个相关结果")
            return results
        except Exception as e:
            logger.error(f"文件系统搜索失败: {e}")
            return []
    
    def get_analysis_by_key(self, issue_key: str) -> Optional[Dict]:
        """
        通过问题键获取分析结果
        
        Args:
            issue_key: 问题键
            
        Returns:
            分析结果或None
        """
        file_path = self.base_path / f"{issue_key}.json"
        if file_path.exists():
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"读取分析结果时出错: {e}")
        
        return None 