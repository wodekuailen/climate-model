"""
知识库包初始化文件
"""
from agent.knowledge.knowledge_base import KnowledgeBase

__all__ = ["KnowledgeBase"] 