"""
Agent核心模块，实现基于LangGraph的智能分析Agent
"""
from typing import Dict, List, Optional, Any, Tuple, Callable
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from langchain_ollama import ChatOllama
from langgraph.graph import StateGraph, END
import json
import re
from pathlib import Path
import logging
from datetime import datetime

# 导入自定义模块
from agent.tools.log_analyzer import LogAnalyzer
from agent.tools.code_analyzer import CodeAnalyzer
from agent.knowledge.knowledge_base import KnowledgeBase
from integrations.git_integration import GitAnalyzer
from integrations.jira_integration import JiraIntegration
from config.config import (
    MODEL_PROVIDER, OPENAI_API_KEY, OPENAI_MODEL,
    OLLAMA_HOST, OLLAMA_MODEL
)

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class AnalysisAgent:
    """基于LangGraph的智能分析Agent，实现假设-验证循环和动态知识库"""
    
    def __init__(self, 
                repo_path: str,
                jira_config: Optional[Dict] = None,
                model_provider: str = MODEL_PROVIDER,
                model_name: Optional[str] = None,
                api_key: Optional[str] = None,
                ollama_host: str = OLLAMA_HOST,
                knowledge_base_path: str = "./knowledge_base"):
        """
        初始化分析Agent
        
        Args:
            repo_path: 代码仓库路径
            jira_config: Jira配置，包含url, username, api_token
            model_provider: 模型提供商，可选：openai, ollama
            model_name: 语言模型名称
            api_key: API密钥（仅用于OpenAI）
            ollama_host: Ollama主机地址（仅用于Ollama）
            knowledge_base_path: 知识库路径
        """
        self.repo_path = repo_path
        self.model_provider = model_provider
        self.knowledge_base_path = knowledge_base_path
        
        # 初始化工具
        self.log_analyzer = LogAnalyzer()
        self.code_analyzer = CodeAnalyzer(repo_path)
        self.git_analyzer = GitAnalyzer(repo_path)
        self.knowledge_base = KnowledgeBase(knowledge_base_path)
        
        # 初始化Jira集成（如果提供了配置）
        self.jira_integration = None
        if jira_config and all(k in jira_config for k in ["url", "username", "api_token"]):
            try:
                self.jira_integration = JiraIntegration(
                    jira_config["url"], 
                    jira_config["username"], 
                    jira_config["api_token"]
                )
            except Exception as e:
                logger.warning(f"无法初始化Jira集成: {e}")
        
        # 初始化语言模型
        if model_provider.lower() == "openai":
            self.model_name = model_name or OPENAI_MODEL
            self.llm = ChatOpenAI(
                model=self.model_name, 
                api_key=api_key or OPENAI_API_KEY, 
                temperature=0
            )
            logger.info(f"使用OpenAI模型: {self.model_name}")
        elif model_provider.lower() == "ollama":
            self.model_name = model_name or OLLAMA_MODEL
            self.llm = ChatOllama(
                model=self.model_name,
                base_url=ollama_host,
                temperature=0
            )
            logger.info(f"使用Ollama模型: {self.model_name}")
        else:
            raise ValueError(f"不支持的模型提供商: {model_provider}")
        
        # 构建Agent图
        self.graph = self._build_graph()
    
    def _build_graph(self) -> StateGraph:
        """构建Agent的状态图"""
        # 定义状态类型
        class AgentState(dict):
            """Agent状态"""
            issue_key: Optional[str]
            log_content: Optional[str]
            analysis_results: Dict
            current_hypothesis: Optional[str]
            verification_results: List[Dict]
            conclusion: Optional[str]
            next_steps: List[str]
            knowledge_base_entries: List[Dict]
        
        # 创建状态图
        graph = StateGraph(AgentState)
        
        # 添加节点
        
        # 1. 初始分析节点
        graph.add_node("initial_analysis", self._initial_analysis)
        
        # 2. 形成假设节点
        graph.add_node("form_hypothesis", self._form_hypothesis)
        
        # 3. 验证假设节点
        graph.add_node("verify_hypothesis", self._verify_hypothesis)
        
        # 4. 形成结论节点
        graph.add_node("form_conclusion", self._form_conclusion)
        
        # 5. 查询知识库节点
        graph.add_node("query_knowledge_base", self._query_knowledge_base)
        
        # 6. 更新知识库节点
        graph.add_node("update_knowledge_base", self._update_knowledge_base)
        
        # 添加边
        
        # 从初始分析到形成假设
        graph.add_edge("initial_analysis", "form_hypothesis")
        
        # 从形成假设到验证假设
        graph.add_edge("form_hypothesis", "verify_hypothesis")
        
        # 从验证假设到决策点
        graph.add_conditional_edges(
            "verify_hypothesis",
            self._should_continue_verification,
            {
                "continue": "form_hypothesis",  # 继续形成新的假设
                "conclude": "form_conclusion"   # 形成最终结论
            }
        )
        
        # 从形成结论到查询知识库
        graph.add_edge("form_conclusion", "query_knowledge_base")
        
        # 从查询知识库到更新知识库
        graph.add_edge("query_knowledge_base", "update_knowledge_base")
        
        # 从更新知识库到结束
        graph.add_edge("update_knowledge_base", END)
        
        # 设置入口节点
        graph.set_entry_point("initial_analysis")
        
        return graph
    
    def _initial_analysis(self, state: Dict) -> Dict:
        """初始分析日志内容"""
        logger.info("执行初始分析...")
        
        log_content = state.get("log_content", "")
        if not log_content:
            return {
                **state,
                "analysis_results": {"error": "未提供日志内容"},
                "next_steps": ["需要提供日志内容进行分析"]
            }
        
        # 分析日志
        analysis_results = self.log_analyzer.analyze_log(log_content)
        
        # 提取可能相关的代码组件
        components = []
        if "stack_traces" in analysis_results and analysis_results["stack_traces"]:
            components = self.log_analyzer.find_related_code_components(analysis_results["stack_traces"])
        
        # 更新状态
        return {
            **state,
            "analysis_results": {
                **analysis_results,
                "components": components
            },
            "verification_results": []
        }
    
    def _form_hypothesis(self, state: Dict) -> Dict:
        """根据分析结果形成假设"""
        logger.info("形成假设...")
        
        # 准备提示
        prompt_template = """
        你是一个专业的软件问题诊断专家。根据以下信息，形成一个关于问题根本原因的假设：
        
        ## 日志分析结果
        {analysis_results}
        
        ## 已验证的假设
        {verification_results}
        
        请形成一个具体的假设，说明可能的根本原因，并指出需要验证的具体代码组件或系统部分。
        你的假设应该具体明确，可以通过代码分析或Git历史查询进行验证。
        
        输出格式：
        {{
            "hypothesis": "你的假设描述",
            "components_to_check": ["组件1", "组件2"],
            "verification_approach": "验证方法描述"
        }}
        """
        
        prompt = ChatPromptTemplate.from_template(prompt_template)
        
        # 准备输入
        analysis_results_str = json.dumps(state["analysis_results"], ensure_ascii=False, indent=2)
        verification_results_str = json.dumps(state.get("verification_results", []), ensure_ascii=False, indent=2)
        
        # 运行提示
        chain = prompt | self.llm | StrOutputParser()
        result = chain.invoke({
            "analysis_results": analysis_results_str,
            "verification_results": verification_results_str
        })
        
        # 解析结果
        try:
            hypothesis_data = json.loads(result)
        except json.JSONDecodeError:
            # 如果无法解析为JSON，尝试从文本中提取
            hypothesis_data = {
                "hypothesis": result,
                "components_to_check": [],
                "verification_approach": "分析相关代码"
            }
        
        # 更新状态
        return {
            **state,
            "current_hypothesis": hypothesis_data
        }
    
    def _verify_hypothesis(self, state: Dict) -> Dict:
        """验证当前假设"""
        logger.info("验证假设...")
        
        hypothesis = state.get("current_hypothesis", {})
        if not hypothesis:
            return {
                **state,
                "verification_results": state.get("verification_results", []) + [{
                    "hypothesis": "无假设",
                    "verified": False,
                    "reason": "未提供假设"
                }]
            }
        
        # 获取要检查的组件
        components_to_check = hypothesis.get("components_to_check", [])
        verification_approach = hypothesis.get("verification_approach", "")
        
        verification_result = {
            "hypothesis": hypothesis.get("hypothesis", ""),
            "verified": False,
            "evidence": [],
            "reason": ""
        }
        
        # 根据组件查找相关文件
        relevant_files = []
        for component in components_to_check:
            files = self.code_analyzer.find_files_by_component(component)
            relevant_files.extend(files)
        
        # 去重
        relevant_files = list(set(relevant_files))
        
        # 如果找到相关文件，分析它们
        if relevant_files:
            verification_result["evidence"].append(f"找到相关文件: {relevant_files}")
            
            # 分析数据库操作（如果假设与数据库相关）
            if any(kw in verification_approach.lower() for kw in ["数据库", "database", "sql", "query"]):
                for file in relevant_files[:3]:  # 限制分析的文件数量
                    db_operations = self.code_analyzer.analyze_database_operations(file)
                    if db_operations:
                        verification_result["evidence"].append({
                            "file": file,
                            "database_operations": db_operations
                        })
            
            # 查找最近的代码修改
            for file in relevant_files[:3]:
                try:
                    file_history = self.git_analyzer.get_file_history(file, max_commits=3)
                    if file_history:
                        verification_result["evidence"].append({
                            "file": file,
                            "recent_changes": file_history
                        })
                except Exception as e:
                    logger.warning(f"获取文件历史时出错: {e}")
        
        # 使用LLM评估证据并确定假设是否被验证
        prompt_template = """
        作为软件问题诊断专家，请评估以下假设是否得到了证据的支持：
        
        ## 假设
        {hypothesis}
        
        ## 收集的证据
        {evidence}
        
        请分析证据是否支持该假设，并给出详细的理由。
        
        输出格式：
        {{
            "verified": true/false,
            "reason": "详细的理由",
            "confidence": 0-1之间的数字
        }}
        """
        
        prompt = ChatPromptTemplate.from_template(prompt_template)
        
        # 准备输入
        hypothesis_str = json.dumps(hypothesis.get("hypothesis", ""), ensure_ascii=False)
        evidence_str = json.dumps(verification_result["evidence"], ensure_ascii=False, indent=2)
        
        # 运行提示
        chain = prompt | self.llm | StrOutputParser()
        result = chain.invoke({
            "hypothesis": hypothesis_str,
            "evidence": evidence_str
        })
        
        # 解析结果
        try:
            evaluation = json.loads(result)
            verification_result["verified"] = evaluation.get("verified", False)
            verification_result["reason"] = evaluation.get("reason", "")
            verification_result["confidence"] = evaluation.get("confidence", 0)
        except json.JSONDecodeError:
            verification_result["reason"] = "无法解析评估结果"
        
        # 更新状态
        return {
            **state,
            "verification_results": state.get("verification_results", []) + [verification_result]
        }
    
    def _should_continue_verification(self, state: Dict) -> str:
        """决定是继续验证还是形成结论"""
        verification_results = state.get("verification_results", [])
        
        # 如果没有验证结果，继续验证
        if not verification_results:
            return "continue"
        
        # 检查是否有被验证的假设
        verified_hypotheses = [r for r in verification_results if r.get("verified", False)]
        
        # 如果已经有足够的验证假设或者验证次数达到上限，形成结论
        if verified_hypotheses or len(verification_results) >= 3:
            return "conclude"
        
        # 否则继续验证
        return "continue"
    
    def _form_conclusion(self, state: Dict) -> Dict:
        """根据验证结果形成结论"""
        logger.info("形成结论...")
        
        # 准备提示
        prompt_template = """
        作为软件问题诊断专家，请根据以下信息形成关于问题的最终结论：
        
        ## 日志分析结果
        {analysis_results}
        
        ## 验证结果
        {verification_results}
        
        请提供详细的问题诊断结论，包括：
        1. 问题的根本原因
        2. 问题的影响范围
        3. 建议的解决方案
        4. 预防类似问题的建议
        
        输出格式：
        {{
            "root_cause": "根本原因描述",
            "impact": "影响范围描述",
            "solution": "解决方案描述",
            "prevention": "预防措施描述",
            "issue_type": "问题类型（如：数据库问题、网络问题等）",
            "severity": "严重程度（低/中/高/严重）"
        }}
        """
        
        prompt = ChatPromptTemplate.from_template(prompt_template)
        
        # 准备输入
        analysis_results_str = json.dumps(state["analysis_results"], ensure_ascii=False, indent=2)
        verification_results_str = json.dumps(state.get("verification_results", []), ensure_ascii=False, indent=2)
        
        # 运行提示
        chain = prompt | self.llm | StrOutputParser()
        result = chain.invoke({
            "analysis_results": analysis_results_str,
            "verification_results": verification_results_str
        })
        
        # 解析结果
        try:
            conclusion = json.loads(result)
        except json.JSONDecodeError:
            # 如果无法解析为JSON，使用原始文本
            conclusion = {
                "root_cause": result,
                "issue_type": "未分类",
                "severity": "未确定"
            }
        
        # 更新状态
        return {
            **state,
            "conclusion": conclusion
        }
    
    def _query_knowledge_base(self, state: Dict) -> Dict:
        """查询知识库中的相关条目"""
        logger.info("查询知识库...")
        
        conclusion = state.get("conclusion", {})
        if not conclusion:
            return {
                **state,
                "knowledge_base_entries": []
            }
        
        # 根据结论中的问题类型和根本原因查询知识库
        issue_type = conclusion.get("issue_type", "")
        root_cause = conclusion.get("root_cause", "")
        
        # 构建查询
        query = f"{issue_type} {root_cause}"
        
        # 搜索知识库
        similar_entries = self.knowledge_base.search_knowledge_base(query)
        
        # 更新状态
        return {
            **state,
            "knowledge_base_entries": similar_entries
        }
    
    def _update_knowledge_base(self, state: Dict) -> Dict:
        """更新知识库"""
        logger.info("更新知识库...")
        
        issue_key = state.get("issue_key", f"UNKNOWN_{datetime.now().strftime('%Y%m%d%H%M%S')}")
        conclusion = state.get("conclusion", {})
        analysis_results = state.get("analysis_results", {})
        verification_results = state.get("verification_results", [])
        
        if not conclusion:
            return state
        
        # 构建分析结果数据
        analysis_data = {
            "conclusion": conclusion,
            "analysis_results": analysis_results,
            "verification_results": verification_results,
            "timestamp": datetime.now().isoformat()
        }
        
        # 存储到知识库
        self.knowledge_base.store_analysis(issue_key, analysis_data)
        
        # 如果配置了Jira集成，也存储到Jira
        if self.jira_integration and issue_key.startswith("UNKNOWN_") is False:
            try:
                self.jira_integration.store_analysis_result(
                    issue_key, 
                    analysis_data, 
                    self.knowledge_base_path
                )
                
                # 添加评论
                comment = f"""
                问题分析完成：
                
                根本原因：{conclusion.get('root_cause', '未确定')}
                问题类型：{conclusion.get('issue_type', '未分类')}
                严重程度：{conclusion.get('severity', '未确定')}
                
                建议解决方案：{conclusion.get('solution', '无')}
                """
                
                self.jira_integration.add_comment(issue_key, comment)
            except Exception as e:
                logger.warning(f"更新Jira时出错: {e}")
        
        return state
    
    def analyze_log(self, log_content: str, issue_key: Optional[str] = None) -> Dict:
        """
        分析日志内容
        
        Args:
            log_content: 日志内容
            issue_key: 可选的问题键
            
        Returns:
            分析结果
        """
        # 初始状态
        initial_state = {
            "issue_key": issue_key,
            "log_content": log_content,
            "analysis_results": {},
            "verification_results": [],
            "conclusion": None,
            "knowledge_base_entries": []
        }
        
        # 运行图
        try:
            result = self.graph.invoke(initial_state)
            return {
                "issue_key": issue_key,
                "conclusion": result.get("conclusion", {}),
                "verification_results": result.get("verification_results", []),
                "knowledge_base_entries": result.get("knowledge_base_entries", [])
            }
        except Exception as e:
            logger.error(f"运行分析图时出错: {e}")
            return {
                "error": str(e),
                "issue_key": issue_key
            }
    
    def analyze_jira_issue(self, issue_key: str) -> Dict:
        """
        分析Jira问题
        
        Args:
            issue_key: Jira问题键
            
        Returns:
            分析结果
        """
        if not self.jira_integration:
            return {"error": "未配置Jira集成"}
        
        try:
            # 获取问题信息
            issue = self.jira_integration.get_issue(issue_key)
            
            if not issue:
                return {"error": f"无法获取问题 {issue_key}"}
            
            # 提取日志内容
            log_content = issue.get("description", "")
            
            # 如果有评论，也提取其中的日志内容
            if "comments" in issue:
                for comment in issue["comments"]:
                    log_content += "\n\n" + comment.get("body", "")
            
            # 分析日志
            return self.analyze_log(log_content, issue_key)
        except Exception as e:
            logger.error(f"分析Jira问题时出错: {e}")
            return {
                "error": str(e),
                "issue_key": issue_key
            } 