"""
FastAPI后端，提供智能分析Agent的API接口
"""
import os
import json
import logging
from typing import Dict, List, Optional, Any
from pathlib import Path
from datetime import datetime
import uuid

from fastapi import FastAPI, HTTPException, BackgroundTasks, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from agent.core import AnalysisAgent
from config.config import (
    MODEL_PROVIDER, OPENAI_API_KEY, OPENAI_MODEL,
    OLLAMA_HOST, OLLAMA_MODEL,
    CODE_REPOSITORY_PATH, KNOWLEDGE_BASE_PATH
)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("api.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# 创建FastAPI应用
app = FastAPI(
    title="智能分析Agent API",
    description="基于LangGraph的智能分析Agent API",
    version="1.0.0"
)

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 允许所有来源，生产环境应该限制
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 创建静态文件目录
os.makedirs("uploads", exist_ok=True)
os.makedirs("results", exist_ok=True)

# 挂载静态文件
app.mount("/static", StaticFiles(directory="static"), name="static")

# 创建Agent实例
agent = AnalysisAgent(
    repo_path=CODE_REPOSITORY_PATH,
    jira_config=None,  # 暂时不使用Jira
    model_provider=MODEL_PROVIDER,
    model_name=OLLAMA_MODEL if MODEL_PROVIDER.lower() == "ollama" else OPENAI_MODEL,
    api_key=OPENAI_API_KEY,
    ollama_host=OLLAMA_HOST,
    knowledge_base_path=KNOWLEDGE_BASE_PATH
)

# 定义请求模型
class LogAnalysisRequest(BaseModel):
    log_content: str
    issue_key: Optional[str] = None

class AnalysisResult(BaseModel):
    task_id: str
    status: str
    result: Optional[Dict] = None
    error: Optional[str] = None
    created_at: str
    completed_at: Optional[str] = None

# 存储任务状态
analysis_tasks = {}

# 路由
@app.get("/")
async def root():
    """API根路径"""
    return {"message": "智能分析Agent API正在运行"}

@app.post("/analyze/log", response_model=Dict)
async def analyze_log(request: LogAnalysisRequest, background_tasks: BackgroundTasks):
    """分析日志内容"""
    task_id = str(uuid.uuid4())
    
    # 创建任务
    analysis_tasks[task_id] = {
        "task_id": task_id,
        "status": "pending",
        "result": None,
        "error": None,
        "created_at": datetime.now().isoformat(),
        "completed_at": None
    }
    
    # 在后台运行分析
    background_tasks.add_task(
        run_analysis_task,
        task_id,
        request.log_content,
        request.issue_key
    )
    
    return {
        "task_id": task_id,
        "status": "pending",
        "message": "分析任务已提交"
    }

@app.post("/analyze/file", response_model=Dict)
async def analyze_file(background_tasks: BackgroundTasks, file: UploadFile = File(...)):
    """分析上传的日志文件"""
    task_id = str(uuid.uuid4())
    
    # 保存上传的文件
    file_path = f"uploads/{task_id}_{file.filename}"
    with open(file_path, "wb") as f:
        content = await file.read()
        f.write(content)
    
    # 读取文件内容
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        log_content = f.read()
    
    # 创建任务
    analysis_tasks[task_id] = {
        "task_id": task_id,
        "status": "pending",
        "result": None,
        "error": None,
        "created_at": datetime.now().isoformat(),
        "completed_at": None,
        "file_path": file_path
    }
    
    # 在后台运行分析
    background_tasks.add_task(
        run_analysis_task,
        task_id,
        log_content,
        None  # 没有issue_key
    )
    
    return {
        "task_id": task_id,
        "status": "pending",
        "message": "文件已上传，分析任务已提交"
    }

@app.get("/tasks/{task_id}", response_model=Dict)
async def get_task_status(task_id: str):
    """获取任务状态"""
    if task_id not in analysis_tasks:
        raise HTTPException(status_code=404, detail="任务不存在")
    
    return analysis_tasks[task_id]

@app.get("/tasks", response_model=List[Dict])
async def list_tasks():
    """列出所有任务"""
    return list(analysis_tasks.values())

@app.get("/knowledge/search")
async def search_knowledge(query: str, limit: int = 5):
    """搜索知识库"""
    try:
        results = agent.knowledge_base.search_knowledge_base(query, top_k=limit)
        return {"results": results}
    except Exception as e:
        logger.error(f"搜索知识库时出错: {e}")
        raise HTTPException(status_code=500, detail=f"搜索知识库时出错: {str(e)}")

@app.get("/knowledge/{issue_key}")
async def get_knowledge_item(issue_key: str):
    """获取知识库中的特定条目"""
    try:
        result = agent.knowledge_base.get_analysis_by_key(issue_key)
        if not result:
            raise HTTPException(status_code=404, detail=f"未找到问题 {issue_key} 的分析结果")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"获取知识库条目时出错: {e}")
        raise HTTPException(status_code=500, detail=f"获取知识库条目时出错: {str(e)}")

# 辅助函数
async def run_analysis_task(task_id: str, log_content: str, issue_key: Optional[str] = None):
    """在后台运行分析任务"""
    try:
        # 更新任务状态为进行中
        analysis_tasks[task_id]["status"] = "processing"
        
        # 运行分析
        result = agent.analyze_log(log_content, issue_key)
        
        # 保存结果
        result_path = f"results/{task_id}.json"
        with open(result_path, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        # 更新任务状态为完成
        analysis_tasks[task_id].update({
            "status": "completed",
            "result": result,
            "completed_at": datetime.now().isoformat(),
            "result_path": result_path
        })
    except Exception as e:
        logger.error(f"分析任务出错: {e}")
        # 更新任务状态为失败
        analysis_tasks[task_id].update({
            "status": "failed",
            "error": str(e),
            "completed_at": datetime.now().isoformat()
        })

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000) 