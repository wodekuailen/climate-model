"""
Jira集成模块，用于与Jira缺陷管理系统交互
"""
from typing import Dict, List, Optional, Any
from jira import JIRA
import json
import os
from datetime import datetime
from pathlib import Path

class JiraIntegration:
    """Jira集成类，用于与Jira系统交互"""
    
    def __init__(self, url: str, username: str, api_token: str):
        """
        初始化Jira集成
        
        Args:
            url: Jira服务器URL
            username: Jira用户名
            api_token: Jira API令牌
        """
        self.url = url
        self.username = username
        self.api_token = api_token
        
        try:
            self.jira = JIRA(server=url, basic_auth=(username, api_token))
        except Exception as e:
            raise ConnectionError(f"无法连接到Jira: {e}")
    
    def create_issue(self, project_key: str, summary: str, description: str, 
                    issue_type: str = "Bug", priority: str = "Medium", 
                    labels: Optional[List[str]] = None, 
                    custom_fields: Optional[Dict[str, Any]] = None) -> Dict:
        """
        创建Jira问题
        
        Args:
            project_key: 项目键
            summary: 问题摘要
            description: 问题描述
            issue_type: 问题类型
            priority: 优先级
            labels: 标签列表
            custom_fields: 自定义字段
            
        Returns:
            创建的问题信息
        """
        issue_dict = {
            'project': {'key': project_key},
            'summary': summary,
            'description': description,
            'issuetype': {'name': issue_type},
        }
        
        if labels:
            issue_dict['labels'] = labels
        
        if custom_fields:
            issue_dict.update(custom_fields)
        
        try:
            issue = self.jira.create_issue(fields=issue_dict)
            return {
                "id": issue.id,
                "key": issue.key,
                "self": issue.self
            }
        except Exception as e:
            print(f"Error creating Jira issue: {e}")
            return {}
    
    def update_issue(self, issue_key: str, fields: Dict[str, Any]) -> bool:
        """
        更新Jira问题
        
        Args:
            issue_key: 问题键
            fields: 要更新的字段
            
        Returns:
            是否更新成功
        """
        try:
            issue = self.jira.issue(issue_key)
            issue.update(fields=fields)
            return True
        except Exception as e:
            print(f"Error updating Jira issue {issue_key}: {e}")
            return False
    
    def add_comment(self, issue_key: str, comment: str) -> bool:
        """
        添加评论到Jira问题
        
        Args:
            issue_key: 问题键
            comment: 评论内容
            
        Returns:
            是否添加成功
        """
        try:
            self.jira.add_comment(issue_key, comment)
            return True
        except Exception as e:
            print(f"Error adding comment to Jira issue {issue_key}: {e}")
            return False
    
    def add_attachment(self, issue_key: str, file_path: str) -> bool:
        """
        添加附件到Jira问题
        
        Args:
            issue_key: 问题键
            file_path: 附件文件路径
            
        Returns:
            是否添加成功
        """
        try:
            with open(file_path, 'rb') as f:
                self.jira.add_attachment(issue_key, f)
            return True
        except Exception as e:
            print(f"Error adding attachment to Jira issue {issue_key}: {e}")
            return False
    
    def get_issue(self, issue_key: str) -> Dict:
        """
        获取Jira问题信息
        
        Args:
            issue_key: 问题键
            
        Returns:
            问题信息字典
        """
        try:
            issue = self.jira.issue(issue_key)
            
            # 提取基本信息
            issue_dict = {
                "id": issue.id,
                "key": issue.key,
                "summary": issue.fields.summary,
                "description": issue.fields.description,
                "status": issue.fields.status.name,
                "created": issue.fields.created,
                "updated": issue.fields.updated,
                "reporter": {
                    "name": issue.fields.reporter.displayName,
                    "email": issue.fields.reporter.emailAddress
                } if hasattr(issue.fields.reporter, "emailAddress") else {"name": issue.fields.reporter.displayName},
                "assignee": {
                    "name": issue.fields.assignee.displayName,
                    "email": issue.fields.assignee.emailAddress
                } if issue.fields.assignee and hasattr(issue.fields.assignee, "emailAddress") else None,
                "priority": issue.fields.priority.name if hasattr(issue.fields, "priority") and issue.fields.priority else None,
                "labels": issue.fields.labels
            }
            
            # 提取评论
            if hasattr(issue.fields, "comment"):
                issue_dict["comments"] = []
                for comment in issue.fields.comment.comments:
                    issue_dict["comments"].append({
                        "id": comment.id,
                        "author": comment.author.displayName,
                        "body": comment.body,
                        "created": comment.created
                    })
            
            return issue_dict
        except Exception as e:
            print(f"Error getting Jira issue {issue_key}: {e}")
            return {}
    
    def search_issues(self, jql_query: str, max_results: int = 50) -> List[Dict]:
        """
        搜索Jira问题
        
        Args:
            jql_query: JQL查询语句
            max_results: 最大结果数
            
        Returns:
            问题列表
        """
        try:
            issues = self.jira.search_issues(jql_query, maxResults=max_results)
            
            result = []
            for issue in issues:
                issue_dict = {
                    "id": issue.id,
                    "key": issue.key,
                    "summary": issue.fields.summary,
                    "status": issue.fields.status.name,
                    "created": issue.fields.created,
                    "updated": issue.fields.updated
                }
                result.append(issue_dict)
            
            return result
        except Exception as e:
            print(f"Error searching Jira issues with query '{jql_query}': {e}")
            return []
    
    def store_analysis_result(self, issue_key: str, analysis_result: Dict, 
                            knowledge_base_path: str = "./knowledge_base") -> bool:
        """
        存储分析结果到知识库
        
        Args:
            issue_key: 问题键
            analysis_result: 分析结果
            knowledge_base_path: 知识库路径
            
        Returns:
            是否存储成功
        """
        try:
            # 确保知识库目录存在
            kb_dir = Path(knowledge_base_path)
            kb_dir.mkdir(exist_ok=True)
            
            # 创建问题目录
            issue_dir = kb_dir / issue_key
            issue_dir.mkdir(exist_ok=True)
            
            # 存储分析结果
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_path = issue_dir / f"analysis_{timestamp}.json"
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(analysis_result, f, ensure_ascii=False, indent=2)
            
            # 添加分析结果链接到Jira评论
            comment = f"分析结果已保存到知识库: {file_path}"
            self.add_comment(issue_key, comment)
            
            return True
        except Exception as e:
            print(f"Error storing analysis result for Jira issue {issue_key}: {e}")
            return False
    
    def get_knowledge_base_entries(self, issue_type: Optional[str] = None, 
                                knowledge_base_path: str = "./knowledge_base") -> List[Dict]:
        """
        获取知识库条目
        
        Args:
            issue_type: 问题类型过滤
            knowledge_base_path: 知识库路径
            
        Returns:
            知识库条目列表
        """
        entries = []
        try:
            kb_dir = Path(knowledge_base_path)
            if not kb_dir.exists():
                return []
            
            # 遍历知识库目录
            for issue_dir in kb_dir.iterdir():
                if not issue_dir.is_dir():
                    continue
                
                issue_key = issue_dir.name
                
                # 如果指定了问题类型，则获取问题信息并过滤
                if issue_type:
                    issue = self.get_issue(issue_key)
                    if not issue or issue.get("issuetype", {}).get("name") != issue_type:
                        continue
                
                # 获取分析结果文件
                analysis_files = list(issue_dir.glob("analysis_*.json"))
                
                for file_path in analysis_files:
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            analysis = json.load(f)
                        
                        entries.append({
                            "issue_key": issue_key,
                            "file_path": str(file_path),
                            "timestamp": file_path.stem.split('_')[1],
                            "analysis": analysis
                        })
                    except Exception as e:
                        print(f"Error reading analysis file {file_path}: {e}")
            
            # 按时间戳排序
            entries.sort(key=lambda x: x["timestamp"], reverse=True)
        except Exception as e:
            print(f"Error getting knowledge base entries: {e}")
        
        return entries 