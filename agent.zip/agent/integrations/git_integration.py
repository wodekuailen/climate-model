"""
Git集成模块，用于与Git版本控制系统交互
"""
import os
import git
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from pathlib import Path

class GitAnalyzer:
    """Git分析工具类，用于分析代码仓库的版本历史"""
    
    def __init__(self, repo_path: str):
        """
        初始化Git分析工具
        
        Args:
            repo_path: Git仓库路径
        """
        self.repo_path = Path(repo_path)
        try:
            self.repo = git.Repo(repo_path)
        except git.InvalidGitRepositoryError:
            raise ValueError(f"{repo_path} 不是有效的Git仓库")
    
    def get_file_history(self, file_path: str, max_commits: int = 10) -> List[Dict]:
        """
        获取文件的修改历史
        
        Args:
            file_path: 文件路径，相对于仓库根目录
            max_commits: 最大提交数量
            
        Returns:
            文件修改历史列表
        """
        file_path = str(Path(file_path).relative_to(self.repo_path) if Path(file_path).is_absolute() else file_path)
        
        history = []
        try:
            # 获取文件的提交历史
            commits = list(self.repo.iter_commits(paths=file_path, max_count=max_commits))
            
            for commit in commits:
                # 获取提交中文件的差异
                diffs = commit.diff(commit.parents[0] if commit.parents else git.NULL_TREE, paths=file_path)
                
                for diff in diffs:
                    if diff.a_path == file_path or diff.b_path == file_path:
                        history.append({
                            "commit_id": commit.hexsha,
                            "author": f"{commit.author.name} <{commit.author.email}>",
                            "date": datetime.fromtimestamp(commit.committed_date).isoformat(),
                            "message": commit.message.strip(),
                            "changes": self._parse_diff(diff)
                        })
        except Exception as e:
            print(f"Error getting file history for {file_path}: {e}")
        
        return history
    
    def _parse_diff(self, diff) -> Dict:
        """解析差异对象"""
        changes = {
            "insertions": 0,
            "deletions": 0,
            "lines_changed": []
        }
        
        try:
            # 尝试获取差异统计信息
            if hasattr(diff, "diff"):
                diff_text = diff.diff.decode('utf-8', errors='replace')
                lines = diff_text.split('\n')
                
                for line in lines:
                    if line.startswith('+') and not line.startswith('+++'):
                        changes["insertions"] += 1
                        changes["lines_changed"].append({"type": "insertion", "content": line[1:]})
                    elif line.startswith('-') and not line.startswith('---'):
                        changes["deletions"] += 1
                        changes["lines_changed"].append({"type": "deletion", "content": line[1:]})
        except Exception as e:
            print(f"Error parsing diff: {e}")
        
        return changes
    
    def blame_file(self, file_path: str, line_start: int = 1, line_end: Optional[int] = None) -> List[Dict]:
        """
        获取文件的责任人信息（blame）
        
        Args:
            file_path: 文件路径，相对于仓库根目录
            line_start: 起始行号
            line_end: 结束行号
            
        Returns:
            文件行责任人信息列表
        """
        file_path = str(Path(file_path).relative_to(self.repo_path) if Path(file_path).is_absolute() else file_path)
        
        blame_info = []
        try:
            # 获取文件内容的总行数
            with open(os.path.join(self.repo_path, file_path), 'r', encoding='utf-8') as f:
                total_lines = len(f.readlines())
            
            if line_end is None or line_end > total_lines:
                line_end = total_lines
            
            # 确保行号有效
            if line_start < 1:
                line_start = 1
            if line_end < line_start:
                return []
            
            # 获取文件的blame信息
            for commit, lines in self.repo.blame('HEAD', file_path):
                for i, line in enumerate(lines):
                    line_num = i + 1
                    if line_start <= line_num <= line_end:
                        blame_info.append({
                            "line": line_num,
                            "commit_id": commit.hexsha,
                            "author": f"{commit.author.name} <{commit.author.email}>",
                            "date": datetime.fromtimestamp(commit.committed_date).isoformat(),
                            "content": line.strip()
                        })
            
            # 按行号排序
            blame_info.sort(key=lambda x: x["line"])
        except Exception as e:
            print(f"Error getting blame info for {file_path}: {e}")
        
        return blame_info
    
    def find_recent_changes(self, days: int = 7, file_pattern: Optional[str] = None) -> List[Dict]:
        """
        查找最近的代码变更
        
        Args:
            days: 最近的天数
            file_pattern: 文件模式，如"*.java"或"src/"
            
        Returns:
            最近变更的列表
        """
        since_date = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        since_date = since_date.replace(day=since_date.day - days)
        
        changes = []
        try:
            # 构建命令参数
            kwargs = {
                'since': since_date.isoformat(),
                'no_merges': True
            }
            
            if file_pattern:
                kwargs['paths'] = file_pattern
            
            # 获取提交
            commits = list(self.repo.iter_commits(**kwargs))
            
            for commit in commits:
                # 获取提交的文件变更
                files_changed = []
                if commit.parents:
                    diffs = commit.diff(commit.parents[0])
                    for diff in diffs:
                        change_type = "modified"
                        if diff.new_file:
                            change_type = "added"
                        elif diff.deleted_file:
                            change_type = "deleted"
                        elif diff.renamed:
                            change_type = "renamed"
                        
                        files_changed.append({
                            "path": diff.b_path,
                            "type": change_type
                        })
                
                changes.append({
                    "commit_id": commit.hexsha,
                    "author": f"{commit.author.name} <{commit.author.email}>",
                    "date": datetime.fromtimestamp(commit.committed_date).isoformat(),
                    "message": commit.message.strip(),
                    "files_changed": files_changed
                })
        except Exception as e:
            print(f"Error finding recent changes: {e}")
        
        return changes 