# 智能分析Agent系统

基于LangGraph的智能分析Agent系统，具有深度分析和无人值守能力，以及构建动态知识库功能。

## 系统架构

系统由以下几个主要部分组成：

1. **核心Agent模块**：使用LangGraph实现"假设-验证"循环，能够分析日志、查询代码库、检查Git历史，并形成结论。
2. **工具模块**：包括日志分析器和代码分析器，用于提取异常信息和分析代码组件。
3. **集成模块**：与Git和Jira系统集成，用于查询版本历史和管理问题。
4. **知识库模块**：基于Milvus向量数据库，存储和检索分析结果，支持相似案例匹配。
5. **Web界面**：包括FastAPI后端和Vue.js前端，提供用户友好的交互界面。

### LangGraph流程

Agent使用LangGraph构建了以下流程：

1. **初始分析**：分析日志内容，提取关键信息
2. **形成假设**：根据分析结果形成可能的根本原因假设
3. **验证假设**：通过代码分析、Git历史等验证假设
4. **形成结论**：根据验证结果形成最终结论
5. **更新知识库**：将分析结果存储到知识库中

## 安装说明

### 前提条件

- Python 3.8+
- Docker (用于运行Milvus)
- Git

### 安装步骤

1. 克隆仓库：
   ```bash
   git clone <repository-url>
   cd agent
   ```

2. 创建虚拟环境（可选但推荐）：
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   # 或
   venv\Scripts\activate  # Windows
   ```

3. 安装依赖：
   ```bash
   pip install -r requirements.txt
   ```

4. 配置环境变量：
   ```bash
   cp .env.example .env
   # 编辑.env文件，设置必要的配置
   ```

## 使用方法

### 启动系统

使用启动脚本启动整个系统：

```bash
python start.py
```

可选参数：
- `--no-milvus`：不启动Milvus服务（如果已经有运行的实例）
- `--port`：Web服务端口，默认为8000
- `--host`：Web服务主机，默认为127.0.0.1
- `--no-browser`：不自动打开浏览器

### 使用Web界面

启动后，浏览器会自动打开Web界面（默认地址：http://127.0.0.1:8000）。

Web界面包含以下功能：

1. **分析日志**：
   - 直接输入日志内容或上传日志文件
   - 查看分析进度和结果

2. **任务列表**：
   - 查看所有分析任务
   - 查看任务详情

3. **知识库**：
   - 搜索知识库
   - 查看知识条目详情

### 使用命令行

也可以使用命令行工具：

```bash
# 分析日志文件
python main.py --mode log --log-file path/to/your/log_file.log

# 分析Jira问题
python main.py --mode jira --jira-key PROJECT-123

# 交互模式
python main.py
```

## 配置选项

编辑`.env`文件配置以下选项：

```
# 模型配置
MODEL_PROVIDER=ollama  # 可选：openai, ollama
OPENAI_API_KEY=your_openai_api_key  # 如果使用OpenAI
OPENAI_MODEL=gpt-4-turbo  # 如果使用OpenAI

# Ollama配置
OLLAMA_HOST=http://localhost:11434
OLLAMA_MODEL=deepseek-r1  # 使用本地部署的deepseek模型

# 代码库路径配置
CODE_REPOSITORY_PATH=./code_repository  # 设置为您要分析的代码仓库路径
```

## 扩展功能

### 添加新的工具

1. 在`agent/tools/`目录下创建新的工具类
2. 在`agent/core.py`中导入并集成新工具

### 自定义分析流程

可以修改`agent/core.py`中的`_build_graph`方法，添加或修改节点和边。

## 故障排除

### Milvus连接问题

如果无法连接到Milvus：

1. 检查Docker是否正在运行
2. 检查Milvus容器状态：`docker ps -a | grep milvus`
3. 查看Milvus日志：`docker logs milvus-standalone`

如果问题仍然存在，系统会自动回退到使用文件系统存储。

### 模型连接问题

如果使用Ollama：
1. 确保Ollama服务已启动
2. 检查模型是否已下载：`ollama list`
3. 如需下载模型：`ollama pull deepseek-r1`

如果使用OpenAI：
1. 检查API密钥是否正确设置
2. 检查网络连接

## 许可证

[MIT License](LICENSE) 