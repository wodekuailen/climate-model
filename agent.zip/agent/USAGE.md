# 使用说明

## 环境配置

1. 复制环境变量示例文件：
   ```
   copy .env.example .env
   ```

2. 编辑`.env`文件，配置以下内容：
   ```
   # 模型配置
   MODEL_PROVIDER=ollama  # 可选：openai, ollama
   OPENAI_API_KEY=your_openai_api_key  # 如果使用OpenAI
   OPENAI_MODEL=gpt-4-turbo  # 如果使用OpenAI
   
   # Ollama配置
   OLLAMA_HOST=http://localhost:11434
   OLLAMA_MODEL=deepseek-r1  # 使用本地部署的deepseek模型
   
   # 代码库路径配置
   CODE_REPOSITORY_PATH=./code_repository  # 设置为您要分析的代码仓库路径
   ```

## 安装依赖

```bash
pip install -r requirements.txt
```

## 使用方法

### 交互式模式

```bash
python main.py
```

### 分析日志文件

```bash
python main.py --mode log --log-file path/to/your/log_file.log
```

### 分析Jira问题

```bash
python main.py --mode jira --jira-key PROJECT-123
```

### 指定使用本地Ollama模型

```bash
python main.py --model-provider ollama --model deepseek-r1
```

### 指定输出文件

```bash
python main.py --mode log --log-file path/to/your/log_file.log --output analysis_result.json
```

## 命令行参数

- `--mode`: 分析模式，可选值：log(分析日志文件)、jira(分析Jira问题)、interactive(交互模式)，默认为interactive
- `--log-file`: 日志文件路径
- `--jira-key`: Jira问题键
- `--repo-path`: 代码仓库路径
- `--kb-path`: 知识库路径
- `--output`: 输出文件路径
- `--model-provider`: 模型提供商，可选值：openai、ollama，默认为ollama
- `--model`: 语言模型名称，如果不指定则使用配置文件中的默认值
- `--ollama-host`: Ollama主机地址，默认为http://localhost:11434 