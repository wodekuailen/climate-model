"""
演示脚本，展示基于LangGraph的Agent流程，无需实际的Jira和Git仓库
"""
import os
import json
import logging
from pathlib import Path
from typing import Dict, List, Any

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 模拟日志内容
SAMPLE_LOG = """
2023-06-15T10:23:45.123Z ERROR [com.example.service.UserService] - Database connection failed: Connection refused
2023-06-15T10:23:45.125Z ERROR [com.example.service.UserService] - Failed to execute query: SELECT * FROM users WHERE id = 123
2023-06-15T10:23:45.130Z ERROR [com.example.service.UserService] - Exception: java.sql.SQLException: Connection refused
2023-06-15T10:23:45.135Z ERROR [com.example.service.UserService] - at com.example.database.DatabaseConnector.connect(DatabaseConnector.java:45)
2023-06-15T10:23:45.140Z ERROR [com.example.service.UserService] - at com.example.service.UserService.getUserById(UserService.java:78)
2023-06-15T10:23:45.145Z ERROR [com.example.service.UserService] - at com.example.controller.UserController.getUser(UserController.java:34)
"""

# 从config导入必要的配置
try:
    from config.config import MODEL_PROVIDER, OLLAMA_MODEL, OLLAMA_HOST
except ImportError:
    # 如果导入失败，使用默认值
    MODEL_PROVIDER = "ollama"
    OLLAMA_MODEL = "deepseek-r1"
    OLLAMA_HOST = "http://localhost:11434"

# 导入LangGraph相关库
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langgraph.graph import StateGraph, END

# 导入模型
if MODEL_PROVIDER.lower() == "ollama":
    from langchain_ollama import ChatOllama
    llm = ChatOllama(model=OLLAMA_MODEL, base_url=OLLAMA_HOST, temperature=0)
    logger.info(f"使用Ollama模型: {OLLAMA_MODEL}")
else:
    from langchain_openai import ChatOpenAI
    llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0)
    logger.info("使用OpenAI模型: gpt-3.5-turbo")

# 定义状态类型
class AgentState(dict):
    """Agent状态"""
    pass

def initial_analysis(state: Dict) -> Dict:
    """初始分析日志内容"""
    logger.info("步骤1: 执行初始分析...")
    
    log_content = state.get("log_content", "")
    if not log_content:
        return {
            **state,
            "analysis_results": {"error": "未提供日志内容"},
            "next_steps": ["需要提供日志内容进行分析"]
        }
    
    # 使用LLM分析日志
    prompt_template = """
    你是一个专业的日志分析专家。请分析以下日志内容，提取关键信息：
    
    ```
    {log_content}
    ```
    
    请提供以下信息：
    1. 异常类型
    2. 可能的错误原因
    3. 涉及的组件或服务
    4. 堆栈跟踪信息
    
    以JSON格式输出，包含以上字段。
    """
    
    prompt = ChatPromptTemplate.from_template(prompt_template)
    chain = prompt | llm | StrOutputParser()
    
    try:
        result = chain.invoke({"log_content": log_content})
        analysis_results = json.loads(result)
    except Exception as e:
        logger.error(f"分析日志时出错: {e}")
        analysis_results = {
            "异常类型": "未知",
            "可能的错误原因": "分析失败",
            "涉及的组件或服务": [],
            "堆栈跟踪信息": []
        }
    
    # 提取可能相关的代码组件
    components = []
    if "涉及的组件或服务" in analysis_results:
        components = analysis_results["涉及的组件或服务"]
    
    logger.info(f"分析结果: {json.dumps(analysis_results, ensure_ascii=False)}")
    
    # 更新状态
    return {
        **state,
        "analysis_results": analysis_results,
        "components": components,
        "verification_results": []
    }

def form_hypothesis(state: Dict) -> Dict:
    """根据分析结果形成假设"""
    logger.info("步骤2: 形成假设...")
    
    # 准备提示
    prompt_template = """
    你是一个专业的软件问题诊断专家。根据以下分析结果，形成一个关于问题根本原因的假设：
    
    ## 分析结果
    {analysis_results}
    
    请形成一个具体的假设，说明可能的根本原因，并指出需要验证的具体代码组件或系统部分。
    
    输出格式：
    {{
        "hypothesis": "你的假设描述",
        "components_to_check": ["组件1", "组件2"],
        "verification_approach": "验证方法描述"
    }}
    """
    
    prompt = ChatPromptTemplate.from_template(prompt_template)
    
    # 准备输入
    analysis_results_str = json.dumps(state.get("analysis_results", {}), ensure_ascii=False, indent=2)
    
    # 运行提示
    chain = prompt | llm | StrOutputParser()
    result = chain.invoke({
        "analysis_results": analysis_results_str
    })
    
    # 解析结果
    try:
        hypothesis_data = json.loads(result)
    except json.JSONDecodeError:
        # 如果无法解析为JSON，尝试从文本中提取
        hypothesis_data = {
            "hypothesis": result,
            "components_to_check": [],
            "verification_approach": "分析相关代码"
        }
    
    logger.info(f"假设: {json.dumps(hypothesis_data, ensure_ascii=False)}")
    
    # 更新状态
    return {
        **state,
        "current_hypothesis": hypothesis_data
    }

def verify_hypothesis(state: Dict) -> Dict:
    """验证当前假设（模拟）"""
    logger.info("步骤3: 验证假设...")
    
    hypothesis = state.get("current_hypothesis", {})
    if not hypothesis:
        return {
            **state,
            "verification_results": state.get("verification_results", []) + [{
                "hypothesis": "无假设",
                "verified": False,
                "reason": "未提供假设"
            }]
        }
    
    # 获取要检查的组件
    components_to_check = hypothesis.get("components_to_check", [])
    
    # 模拟验证过程
    verification_result = {
        "hypothesis": hypothesis.get("hypothesis", ""),
        "verified": False,
        "evidence": [],
        "reason": ""
    }
    
    # 模拟找到相关文件
    relevant_files = [f"{component}.java" for component in components_to_check]
    if relevant_files:
        verification_result["evidence"].append(f"找到相关文件: {relevant_files}")
    
    # 模拟数据库操作分析
    if "database" in hypothesis.get("verification_approach", "").lower():
        verification_result["evidence"].append({
            "file": "DatabaseConnector.java",
            "database_operations": {
                "connection_method": "使用JDBC连接数据库",
                "connection_params": "从配置文件读取连接参数"
            }
        })
    
    # 模拟代码修改历史
    verification_result["evidence"].append({
        "file": "DatabaseConnector.java",
        "recent_changes": [
            {
                "commit_id": "abc123",
                "author": "developer@example.com",
                "date": "2023-06-14T15:30:00Z",
                "message": "修改数据库连接超时参数",
                "changes": {
                    "insertions": 2,
                    "deletions": 1
                }
            }
        ]
    })
    
    # 使用LLM评估证据并确定假设是否被验证
    prompt_template = """
    作为软件问题诊断专家，请评估以下假设是否得到了证据的支持：
    
    ## 假设
    {hypothesis}
    
    ## 收集的证据
    {evidence}
    
    请分析证据是否支持该假设，并给出详细的理由。
    
    输出格式：
    {{
        "verified": true/false,
        "reason": "详细的理由",
        "confidence": 0-1之间的数字
    }}
    """
    
    prompt = ChatPromptTemplate.from_template(prompt_template)
    
    # 准备输入
    hypothesis_str = json.dumps(hypothesis.get("hypothesis", ""), ensure_ascii=False)
    evidence_str = json.dumps(verification_result["evidence"], ensure_ascii=False, indent=2)
    
    # 运行提示
    chain = prompt | llm | StrOutputParser()
    result = chain.invoke({
        "hypothesis": hypothesis_str,
        "evidence": evidence_str
    })
    
    # 解析结果
    try:
        evaluation = json.loads(result)
        verification_result["verified"] = evaluation.get("verified", False)
        verification_result["reason"] = evaluation.get("reason", "")
        verification_result["confidence"] = evaluation.get("confidence", 0)
    except json.JSONDecodeError:
        verification_result["reason"] = "无法解析评估结果"
    
    logger.info(f"验证结果: {json.dumps(verification_result, ensure_ascii=False)}")
    
    # 更新状态
    return {
        **state,
        "verification_results": state.get("verification_results", []) + [verification_result]
    }

def should_continue_verification(state: Dict) -> str:
    """决定是继续验证还是形成结论"""
    verification_results = state.get("verification_results", [])
    
    # 如果没有验证结果，继续验证
    if not verification_results:
        return "continue"
    
    # 检查是否有被验证的假设
    verified_hypotheses = [r for r in verification_results if r.get("verified", False)]
    
    # 如果已经有足够的验证假设或者验证次数达到上限，形成结论
    if verified_hypotheses or len(verification_results) >= 2:  # 为了演示，设置为2
        return "conclude"
    
    # 否则继续验证
    return "continue"

def form_conclusion(state: Dict) -> Dict:
    """根据验证结果形成结论"""
    logger.info("步骤4: 形成结论...")
    
    # 准备提示
    prompt_template = """
    作为软件问题诊断专家，请根据以下信息形成关于问题的最终结论：
    
    ## 分析结果
    {analysis_results}
    
    ## 验证结果
    {verification_results}
    
    请提供详细的问题诊断结论，包括：
    1. 问题的根本原因
    2. 问题的影响范围
    3. 建议的解决方案
    4. 预防类似问题的建议
    
    输出格式：
    {{
        "root_cause": "根本原因描述",
        "impact": "影响范围描述",
        "solution": "解决方案描述",
        "prevention": "预防措施描述",
        "issue_type": "问题类型（如：数据库问题、网络问题等）",
        "severity": "严重程度（低/中/高/严重）"
    }}
    """
    
    prompt = ChatPromptTemplate.from_template(prompt_template)
    
    # 准备输入
    analysis_results_str = json.dumps(state.get("analysis_results", {}), ensure_ascii=False, indent=2)
    verification_results_str = json.dumps(state.get("verification_results", []), ensure_ascii=False, indent=2)
    
    # 运行提示
    chain = prompt | llm | StrOutputParser()
    result = chain.invoke({
        "analysis_results": analysis_results_str,
        "verification_results": verification_results_str
    })
    
    # 解析结果
    try:
        conclusion = json.loads(result)
    except json.JSONDecodeError:
        # 如果无法解析为JSON，使用原始文本
        conclusion = {
            "root_cause": result,
            "issue_type": "未分类",
            "severity": "未确定"
        }
    
    logger.info(f"结论: {json.dumps(conclusion, ensure_ascii=False)}")
    
    # 更新状态
    return {
        **state,
        "conclusion": conclusion
    }

def update_knowledge_base(state: Dict) -> Dict:
    """模拟更新知识库"""
    logger.info("步骤5: 更新知识库...")
    
    issue_key = "DEMO-123"  # 模拟问题ID
    conclusion = state.get("conclusion", {})
    
    if not conclusion:
        return state
    
    # 模拟存储到知识库
    kb_dir = Path("./knowledge_base_demo")
    kb_dir.mkdir(exist_ok=True)
    
    # 构建分析结果数据
    analysis_data = {
        "conclusion": conclusion,
        "analysis_results": state.get("analysis_results", {}),
        "verification_results": state.get("verification_results", []),
        "timestamp": "2023-06-15T12:00:00Z"  # 模拟时间戳
    }
    
    # 模拟保存到文件
    output_file = kb_dir / f"analysis_{issue_key}.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(analysis_data, f, ensure_ascii=False, indent=2)
    
    logger.info(f"分析结果已保存到: {output_file}")
    
    return state

def build_graph() -> StateGraph:
    """构建Agent的状态图"""
    # 创建状态图
    graph = StateGraph(AgentState)
    
    # 添加节点
    graph.add_node("initial_analysis", initial_analysis)
    graph.add_node("form_hypothesis", form_hypothesis)
    graph.add_node("verify_hypothesis", verify_hypothesis)
    graph.add_node("form_conclusion", form_conclusion)
    graph.add_node("update_knowledge_base", update_knowledge_base)
    
    # 添加边
    graph.add_edge("initial_analysis", "form_hypothesis")
    graph.add_edge("form_hypothesis", "verify_hypothesis")
    
    # 从验证假设到决策点
    graph.add_conditional_edges(
        "verify_hypothesis",
        should_continue_verification,
        {
            "continue": "form_hypothesis",  # 继续形成新的假设
            "conclude": "form_conclusion"   # 形成最终结论
        }
    )
    
    # 从形成结论到更新知识库
    graph.add_edge("form_conclusion", "update_knowledge_base")
    
    # 从更新知识库到结束
    graph.add_edge("update_knowledge_base", END)
    
    # 设置入口节点
    graph.set_entry_point("initial_analysis")
    
    return graph

def main():
    """主函数"""
    logger.info("开始演示基于LangGraph的Agent流程...")
    
    # 构建图
    graph = build_graph()
    
    # 可视化图（如果环境支持）
    try:
        from IPython.display import display
        display(graph.get_viewer())
        logger.info("已生成图的可视化视图")
    except:
        logger.info("无法生成图的可视化视图，继续执行...")
    
    # 初始状态
    initial_state = {
        "log_content": SAMPLE_LOG,
    }
    
    # 运行图
    logger.info("开始执行Agent流程...")
    result = graph.invoke(initial_state)
    
    # 输出最终结果
    logger.info("Agent流程执行完成！")
    logger.info("最终结论:")
    print(json.dumps(result.get("conclusion", {}), ensure_ascii=False, indent=2))
    
    # 输出知识库保存位置
    logger.info("分析结果已保存到知识库: ./knowledge_base_demo/")

if __name__ == "__main__":
    main() 