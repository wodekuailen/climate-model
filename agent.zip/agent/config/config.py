"""
配置模块，用于管理Agent的配置信息
"""
import os
from dotenv import load_dotenv
from pathlib import Path

# 加载环境变量
load_dotenv()

# 模型配置
MODEL_PROVIDER = os.getenv("MODEL_PROVIDER", "ollama")  # 可选：openai, ollama
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4-turbo")

# Ollama配置
OLLAMA_HOST = os.getenv("OLLAMA_HOST", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "deepseek-r1")

# Jira配置
JIRA_URL = os.getenv("JIRA_URL")
JIRA_USERNAME = os.getenv("JIRA_USERNAME")
JIRA_API_TOKEN = os.getenv("JIRA_API_TOKEN")

# 代码库路径配置
CODE_REPOSITORY_PATH = os.getenv("CODE_REPOSITORY_PATH", "./code_repository")

# 日志配置
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FILE = os.getenv("LOG_FILE", "agent.log")

# 知识库配置
KNOWLEDGE_BASE_PATH = Path("./knowledge_base")
KNOWLEDGE_BASE_PATH.mkdir(exist_ok=True) 