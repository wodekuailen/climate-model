# 智能问题分析 Agent (完全体)

这是一个基于 LangGraph 构建的高级问题分析 Agent。它通过模拟一位资深软件工程师的思考过程，实现"**搜索经验 -> 假设-验证 -> 记录归档**"的完整诊断循环，从而对复杂的技术问题进行深度、高效的分析。

## 核心特性

- **自主规划与循环推理**: Agent 能够根据初始问题和历史经验，自主地规划调查步骤，并在"规划-行动-观察"的循环中不断迭代，直至找到问题根源。
- **动态知识库 (Milvus)**: Agent 在每次分析前，会先在 Milvus 知识库中搜索相似案例以获取灵感；在每次分析结束后，会将新的解决方案存入知识库，从而实现自我学习和进化。
- **可扩展的真实工具集**: Agent 可以调用真实世界的工具（如 `git grep`, `git blame`, `cat`）来收集证据，也可以与外部服务（如 Jira, 数据库）进行交互。
- **实时反馈**: 整个分析过程通过 WebSocket 实时地展示在前端界面，让用户能清晰地看到 Agent 的每一步思考和行动。

## 技术栈

- **后端**: FastAPI (提供 WebSocket API)
- **前端**: React (使用 Vite 构建)
- **核心逻辑**: LangGraph (构建可循环的 Agentic 图)
- **大语言模型**: 本地 Ollama (本项目默认使用 `qwen2.5:7b` 作为推理和嵌入模型)
- **向量数据库**: Milvus (用于存储和检索历史分析案例)

## 全链路工作流详解 (学习型)

1.  **前端交互**: 用户在 React 界面中输入问题描述。
2.  **知识库检索**: 请求通过 WebSocket 发送到后端。Agent 的**第一步**是调用 `search_knowledge_base` 工具，将用户的问题在 Milvus 知识库中进行相似性搜索。
3.  **情景构建**: 无论是否找到相似案例，搜索结果都会和用户原始问题一起，作为初始上下文，被喂给大语言模型 (LLM)。
4.  **循环诊断 (规划 -> 行动 -> 观察)**:
    - **规划 (Plan)**: LLM 根据当前掌握的所有信息（历史经验、问题描述、之前的工具输出），决定下一步的最佳行动。这可能是调用一个工具，也可能是认为信息足够，可以得出结论。
    - **行动 (Act)**: 如果 LLM 决定使用工具，`ToolExecutor` 会执行对应的真实函数，例如在代码库运行 `git grep`，或读取文件内容。
    - **观察 (Observe)**: 工具的执行结果被包装成消息，再次返回给 LLM。
    - 这个"规划-行动-观察"的循环会持续进行，直到 LLM 认为问题已经解决。
5.  **总结与归档**:
    - **总结 (Summarize)**: 当 LLM 决定结束分析时，它会输出一个以 `FINAL ANSWER:` 开头的最终报告。
    - **归档 (Archive)**: `final_summary_node` 节点被激活，它会将整个分析过程（问题、思考链、工具使用、结论）整理成一份完整的报告，并调用 `add_to_knowledge_base` 函数，将其向量化后存入 Milvus 知识库。
6.  **实时展示**: 在上述的每一个步骤中，Agent 的状态都会通过 WebSocket 实时发送回前端并展示。

## 安装与配置

在开始之前，请确保您的系统已安装以下软件：
- [Node.js](https://nodejs.org/) (LTS 版本)
- [Python](https://www.python.org/) (3.9+)
- [Git](https://git-scm.com/)
- [Docker](https://www.docker.com/) (用于运行 Milvus)
- [Ollama](https://ollama.com/)

#### 1. 启动 Milvus 服务
本项目使用 Milvus 作为向量数据库。最简单的启动方式是使用 Docker。
```bash
# 下载 docker-compose.yml 文件
wget https://milvus.io/docs/install_standalone-docker.md
# 启动 Milvus
docker-compose up -d
```
更多信息请参考 [Milvus 官方文档](https://milvus.io/docs/install_standalone-docker.md)。

#### 2. 后端设置

```bash
# 进入后端目录
cd backend

# (首次需要) 创建 Python 虚拟环境
python -m venv venv

# 激活虚拟环境
# Windows: .\venv\Scripts\activate | macOS/Linux: source venv/bin/activate
.\venv\Scripts\activate

# 安装或更新所有依赖
pip install -r requirements.txt
```

**关键配置：** 在运行之前，请务必打开 `backend/app/tools.py` 文件，根据您的本地环境修改配置区的变量，尤其是 `CODE_REPO_PATH`。

```python
# backend/app/tools.py

# --- 配置区 ---
CODE_REPO_PATH = "D:/path/to/your/git/project" # 必须修改为真实的 Git 仓库路径
JIRA_API_URL = "..." # (可选)
DB_STATUS_ENDPOINT = "..." # (可选)
MILVUS_HOST = "localhost" # Milvus 服务地址
# --- 配置区结束 ---
```

#### 3. 前端设置

```bash
# (在另一个终端中) 进入前端目录
cd frontend
# 安装所有依赖
npm install
```

#### 4. Ollama 模型
请确保您的 Ollama 服务正在运行，并且已下载本项目所需的模型 (`qwen2.5:7b`)。

## 如何运行

1.  **确认依赖服务已启动**:
    - [x] Ollama 服务
    - [x] Milvus 服务

2.  **启动后端服务**:
    在激活了虚拟环境的 `backend` 目录下运行：
    ```bash
    uvicorn app.main:app --reload
    ```

3.  **启动前端服务**:
    在 `frontend` 目录下运行：
    ```bash
    npm run dev
    ```

现在，您的"完全体"Agent 已经准备就绪。享受与一个能够学习和成长的 AI 伙伴一起解决问题的乐趣吧！ 